# -*- coding: utf-8 -*-
"""
Created on Fri Aug 24 12:17:52 2018

@author: kunals
"""
# DATABASE_CONFIG = {
#                     'user': 'root',
#                     'password': 'root#1nV',
#                     'host': '172.16.1.130',
#                     'database': 'vnoc_uat',
#                     'port': 3306,
#                     'raise_on_warnings': True,
#                     }


DATABASE_CONFIG = {
                    'user': 'admin',
                    'password': 'admin_IN5INVRDS1',
                    'host': 'in5invrds1.cgpgt64ntpzz.ap-south-1.rds.amazonaws.com',
                    'database': 'wfm_atc',
                    'port': 3306,
                    'raise_on_warnings': True,
                    }


# DATABASE_CONFIG = {
#                     'user': 'root',
#                     'password': 'Root$1+C',
#                     'host': 'localhost',
#                     'database': 'vnoc_uat',
#                     'port': 3306,
#                     'raise_on_warnings': True,
#                     }
#

PARAMTER_CONFIG = {
                    'backTrackPeriod': 3,
                    'numbersecAdd': 0
        }



DATE_PARAMS = {
        'year' : 2021,
        'start_index' : 19,
        'end_index' : 19,
        'start_month' : 4,
        'end_month' : 4
            }







