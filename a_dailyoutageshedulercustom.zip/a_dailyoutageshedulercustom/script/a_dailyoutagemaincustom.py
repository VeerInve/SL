
# python imports
import datetime
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
import sys


# analysis tool imports
import pandas as pd
import numpy as np

# DB related imports
import pymysql
from sqlalchemy import create_engine
from sqlalchemy import MetaData, Column, Table
from sqlalchemy import String ,Date, Float

# package imports
import setting as settings
import databaseRead


now = datetime.now()
scriptRunTime = now.strftime("%Y-%m-%d %H:%M:%S")
print(scriptRunTime)


try:
    conn = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                           user=settings.DATABASE_CONFIG['user'],
                           password=settings.DATABASE_CONFIG['password'],
                           db=settings.DATABASE_CONFIG['database'])

except pymysql.OperationalError:
    sys.exit()
except pymysql.InternalError:
    sys.exit()

try:
    host = settings.DATABASE_CONFIG['host']
    user = settings.DATABASE_CONFIG['user']
    password = settings.DATABASE_CONFIG['password']
    db = settings.DATABASE_CONFIG['database']
    port = settings.DATABASE_CONFIG['port']

    engine = create_engine('mysql+pymysql://' + user + ':' + password + '@' + host + ':' + str(port) + '/' + db,
                           echo=False)
    metadata = MetaData(bind=engine)

except pymysql.OperationalError:
    sys.exit()
except pymysql.InternalError:
    sys.exit()

year = settings.DATE_PARAMS['year']
start_index =  settings.DATE_PARAMS['start_index']
end_index = settings.DATE_PARAMS['end_index']
start_month =  settings.DATE_PARAMS['start_month']
end_month =  settings.DATE_PARAMS['end_month']

if __name__ == '__main__':
    start_date = date(year, start_month, start_index)
    s_date = start_date.strftime(("%Y-%m-%d"))
    end_date = date(year, end_month, end_index)

    step = timedelta(hours=24)

    while start_date <= end_date:
        b_time_str = str(start_date)
        t_start = " 00:00:00"
        t_end = " 23:59:59"

        start = b_time_str + t_start
        print(start)
        end = b_time_str + t_end
        print(end)

        pattern = '%Y-%m-%d %H:%M:%S'

        start_bound = int(time.mktime(datetime.strptime(start, pattern).timetuple()))
        end_bound = int(time.mktime(datetime.strptime(end, pattern).timetuple()))

        schedulerdate = start_date.strftime(("%Y-%m-%d"))

        """
        Dataset when cleartime is present between scheduler computation date
        """

        MTTRDF = databaseRead.mttrcomputation(conn, start_bound, end_bound)

        if MTTRDF.empty:
            print('No Data is avialable for date = ',schedulerdate)
        else:
    
    
            # MTTRDF.to_excel('D:/Application/aggregator/a_dailyoutageschedulercustom/data/temp_data/mttrtest.xlsx')
            print('Daily Aggregation Started for date = ', schedulerdate)

            """
            Filter Data from MTTRDF where cleartime is between processing date
            Case1: when open date is between processing date
            Case2: when open date is before processing date
            """
            MTTRDF1 = MTTRDF.loc[(MTTRDF['soRestoreDateTime'] >= start_bound) & (MTTRDF['soRestoreDateTime'] <= end_bound)]

            """ Case1: when open date is between processing date"""

            MTTRDF2 = MTTRDF1.loc[(MTTRDF1['soStartDateTime']>=start_bound) & (MTTRDF1['soStartDateTime'] <= end_bound)]
            # computing Outage Minutes
            MTTRDF2['duration'] = MTTRDF2['soRestoreDateTime'] - MTTRDF2['soStartDateTime']
            MTTRDF2['OutageMinutes'] = MTTRDF2['duration'] / 60
            MTTRDF2['OutageMinutes'] = (MTTRDF2['duration'] / 60).round(5)
            MTTRDF2['totalTime'] = 1440
            MTTRDF2['caID'] = 0
            # computing Uptime percentage
            MTTRDF2['UptimeMinutes'] = MTTRDF2['totalTime'] - MTTRDF2['OutageMinutes']
            MTTRDF2['Uptimefraction'] = MTTRDF2['UptimeMinutes'] / MTTRDF2['totalTime'] * 100
            MTTRDF2['PercentageUptime'] = (MTTRDF2['Uptimefraction']).round(3)
            MTTRDF2['dummydate'] = MTTRDF2['soStartDateTime']
            # MTTRDF2.to_excel('D:/Application/aggregator/a_dailyoutageschedulercustom/data/temp_data/mttruptime1.xlsx')

            """ Case2: when open date is before processing date """

            MTTRDF22 = MTTRDF1.loc[(MTTRDF1['soStartDateTime'] < start_bound)]
            # compute Outage Minutes
            MTTRDF22['startticker'] = start_bound
            MTTRDF22['soStartDateTime'] = start_bound
            MTTRDF22['duration'] = MTTRDF22['soRestoreDateTime'] - MTTRDF22['startticker']
            MTTRDF22['OutageMinutes'] = MTTRDF22['duration'] / 60
            MTTRDF22['OutageMinutes'] = (MTTRDF22['duration'] / 60).round(5)
            # computing Uptime percentage
            MTTRDF22['totalTime'] = 1440
            MTTRDF22['caID'] =0
            MTTRDF22['UptimeMinutes'] = MTTRDF22['totalTime'] - MTTRDF22['OutageMinutes']
            MTTRDF22['Uptimefraction'] = MTTRDF22['UptimeMinutes'] / MTTRDF22['totalTime'] * 100
            MTTRDF22['PercentageUptime'] = (MTTRDF22['Uptimefraction']).round(3)
            MTTRDF22['dummydate'] = start_bound
            # MTTRDF22.to_excel('D:/Application/aggregator/a_dailyoutageschedulercustom/data/temp_data/mttruptime2.xlsx')

            """  
            ***********************  Not Considered ***************************************************************
               Filter Data from MTTRDF where cleartime is ahead processing date and on before scheduler running time
               Case1: when open date is between processing date
               Case2: when open date is before processing date
               Case3: When open date is on Scheduler running date
            """

            # concat 3 dataframe
            MTTRDF2 = MTTRDF2[['ttid','znZoneID','znZone','clCircleID','clCircle','crClusterID',
                               'crName','smSiteID','smPaceSiteCode','smSiteName','cmCompanyID',
                               'ssmStatus','soStartDateTime','soRestoreDateTime','OutageMinutes',
                               'PercentageUptime','acAccID','cmCompanyVendorID','socID','sofeID',
                                'ttLastUpdatedDt','alID','alName','smtTypeID','smtTypeName','caID','dummydate'
                            ]]
            MTTRDF22 = MTTRDF22[['ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
                               'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
                               'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
                               'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
                               'ttLastUpdatedDt','alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID','dummydate'
                               ]]


            """
            ***********************  Not Considered ***************************************************************
            Dataset when cleartime is not avialable between processing date
            """

            dfList = [MTTRDF2,MTTRDF22]
            final_df = pd.concat(dfList)
            # final_df['ttLastUpdatedDt'] = 0
            final_df['SchedulerRunDate'] = schedulerdate
            final_df['dayAutoID'] = 0
            final_df = final_df[['SchedulerRunDate','ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
                               'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
                               'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
                               'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
                               'ttLastUpdatedDt','alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID','dummydate'
                               ]]
            # change flag for Normal BSC and STRATEGIC BSC
            final_df.replace(to_replace=["Normal BSC", "STRATEGIC BSC"],
                       value="BSC",inplace=True)
            final_df['socID'].fillna(19,inplace = True)
            final_df['sofeID'].fillna(150,inplace = True)
            #final_df.to_excel('D:/Application/aggregator/a_dailyoutageschedulercustom/data/temp_data/finalcheck.xlsx')
            final_df.to_sql('a_dailyoutage', engine, if_exists='append',index=False)
            print('Daily Aggregation Completed for Date =',start_date)


        start_date += step
    print('')
    print('**************************************************************************')
    print('Daily Aggregation Task Finished between Date ', s_date,' and ',end_date)


