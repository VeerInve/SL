select 
`m_circle`.`clCircleID` AS `clCircleID`,`m_circle`.`clCircle` AS `clCircle`,`m_site`.`crClusterID` AS `crClusterID`,
`m_cluster`.`crName` AS `crName`,`m_site`.`smSiteID` AS `smSiteID`,`m_site`.`smPaceSiteCode` AS `smPaceSiteCode`,
`m_site`.`smSiteName` AS `smSiteName`,`m_site`.`pdId` AS `pdId`,`m_powerdetails`.`pdName` AS `pdName`,
`m_powerdetails`.`pdCategory` AS `pdCategory`,`m_sitestatusmaster`.`ssmStatus` AS `ssmStatus`,
`t_troubleticketlog`.`alID` AS `alID`,`m_alarmnames`.`alName` AS `alName`,`t_troubleticketlog`.`ttEventOpenTime` AS `ttOpenTime`,
`t_troubleticketlog`.`ttClearTime` AS `ttClearTime`,(`t_troubleticketlog`.`ttClearTime` - `t_troubleticketlog`.`ttOpenTime`) AS `ticketDuration` 

from (((

(((`t_troubleticketlog` 
join `m_site` on((`t_troubleticketlog`.`smSiteID` = `m_site`.`smSiteID`))) 
join `m_alarmnames` on((`m_alarmnames`.`alID` = `t_troubleticketlog`.`alID`))) 
join `m_cluster` on((`m_site`.`crClusterID` = `m_cluster`.`crClusterID`))) 
join `m_circle` on((`m_cluster`.`clCircleID` = `m_circle`.`clCircleID`))) 
join `m_sitestatusmaster` on((`m_site`.`ssmID` = `m_sitestatusmaster`.`ssmID`))) 
join `m_powerdetails` on((`m_site`.`pdId` = `m_powerdetails`.`pdID`)))