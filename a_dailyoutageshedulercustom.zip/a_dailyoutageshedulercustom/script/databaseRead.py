import pandas as pd


def mttrcomputation(conn,start, end):

    start_time = start
    end_time = end
    dictCursor = conn.cursor()
    dictCursor.execute(
        """ SELECT 
                    t.ttID AS ttid,
                    m_circle.znZoneID AS znZoneID,
                    m_zone.znZone AS znZone,
                    m_circle.clCircleID AS clCircleID,
                    m_circle.clCircle AS clCircle,
                    m_site.crClusterID AS crClusterID,
                    m_cluster.crName AS crName,
                    m_site.smSiteID AS smSiteID,
                    m_site.smPaceSiteCode AS smPaceSiteCode,
                    m_site.smSiteName AS smSiteName,
                    t.cmCompanyID AS cmCompanyID,
                    m_sitestatusmaster.ssmStatus AS ssmStatus,
                    t.ttOpenTime AS soStartDateTime,
                    t.ttClearTime AS soRestoreDateTime,
                    t.acAccID AS acAccID,
                    m_site.cmCompanyVendorID AS cmCompanyVendorID,
                    t.socID AS socID,
                    t.sofeID AS sofeID,
                    t.ttLastUpdatedDt as ttLastUpdatedDt,
                    t.alID AS alID,
                    m_alarmnames.alName AS alName,
                    m_sitetype.smtTypeID,
                    m_sitetype.smtTypeName,
                    t_visitlog.caID AS caID,
                    m_powerdetails.pdCategory AS pdCategory,
                    m_powerdetails.pdName AS pdName,
                    (t.ttClearTime - t.ttOpenTime) AS ticketDuration 

                    FROM t_troubleticketlog AS t
                      JOIN m_site 
                            ON (t.smSiteID = m_site.smSiteID)
                         JOIN m_alarmnames 
                            ON (t.alID = m_alarmnames.alID)
                         JOIN m_circle 
                            ON (t.clCircleID = m_circle.clCircleID)
                         JOIN m_cluster 
                            ON (m_site.crClusterID = m_cluster.crClusterID)
                         JOIN m_sitestatusmaster 
                            ON (m_site.ssmID = m_sitestatusmaster.ssmID)
                         JOIN m_powerdetails 
                            ON (m_site.pdId = m_powerdetails.pdID) 
                         JOIN m_zone 
                            ON (m_circle.znZoneID = m_zone.znZoneID) 
                         JOIN m_sitetype
                        ON (m_site.smSiteType = m_sitetype.smtTypeID)
                         LEFT JOIN t_visitlog 
                            ON (t.ttID = t_visitlog.ttID)
                   WHERE t.isOutageTT =1  AND t.ttisParent=0 AND t.ttClearTime !=0 AND t.alID = 17 AND t.ttClearTime >= %s AND t.ttClearTime <= %s """,
            (start_time, end_time))

    columns = [column[0] for column in dictCursor.description]

    resultSet = dictCursor.fetchall()
    results = []

    for row in resultSet:
        results.append(dict(zip(columns, row)))

    nums = [x for x in range(len(results))]

    MTTRdict = dict(zip(nums, results))
    MTTR_df = pd.DataFrame.from_dict(MTTRdict, orient='index')

    return MTTR_df

def mttrcomputationfornotcleared(conn,start, end):

    start_time = start
    end_time = end
    dictCursor = conn.cursor()
    dictCursor.execute(
        """ SELECT 
                    t.ttID AS ttid,
                    m_circle.znZoneID AS znZoneID,
                    m_zone.znZone AS znZone,
                    m_circle.clCircleID AS clCircleID,
                    m_circle.clCircle AS clCircle,
                    m_site.crClusterID AS crClusterID,
                    m_cluster.crName AS crName,
                    m_site.smSiteID AS smSiteID,
                    m_site.smPaceSiteCode AS smPaceSiteCode,
                    m_site.smSiteName AS smSiteName,
                    m_site.pdId AS cmCompanyID,
                    m_sitestatusmaster.ssmStatus AS ssmStatus,
                    t.ttOpenTime AS soStartDateTime,
                    t.ttClearTime AS soRestoreDateTime,
                    t.acAccID AS acAccID,
                    m_site.pdId AS cmCompanyVendorID,
                    t.socID AS socID,
                    t.sofeID AS sofeID,
                    t.ttLastUpdatedDt as ttLastUpdatedDt,
                    t.alID AS alID,
                    m_alarmnames.alName AS alName,
                    m_sitetype.smtTypeID,
                    m_sitetype.smtTypeName,
                    t_visitlog.caID AS caID,
                    m_powerdetails.pdCategory AS pdCategory,
                    m_powerdetails.pdName AS pdName

                    FROM t_troubleticketlog AS t
                      JOIN m_site 
                            ON (t.smSiteID = m_site.smSiteID)
                         JOIN m_alarmnames 
                            ON (t.alID = m_alarmnames.alID)
                         JOIN m_circle 
                            ON (t.clCircleID = m_circle.clCircleID)
                         JOIN m_cluster 
                            ON (m_site.crClusterID = m_cluster.crClusterID)
                         JOIN m_sitestatusmaster 
                            ON (m_site.ssmID = m_sitestatusmaster.ssmID)
                         JOIN m_powerdetails 
                            ON (m_site.pdId = m_powerdetails.pdID) 
                         JOIN m_zone 
                            ON (m_circle.znZoneID = m_zone.znZoneID) 
                         JOIN m_sitetype
                        ON (m_site.smSiteType = m_sitetype.smtTypeID)
                         LEFT JOIN t_visitlog 
                            ON (t.ttID = t_visitlog.ttID)
                   WHERE t.isOutageTT =1  AND t.ttisParent=0 AND t.ttClearTime =0 AND t.ttOpenTime >= %s AND t.ttOpenTime <= %s """,
            (start_time, end_time))

    columns = [column[0] for column in dictCursor.description]

    resultSet = dictCursor.fetchall()
    results = []

    for row in resultSet:
        results.append(dict(zip(columns, row)))

    nums = [x for x in range(len(results))]

    MTTRnotcleareddict = dict(zip(nums, results))
    MTTRnotcleared_df = pd.DataFrame.from_dict(MTTRnotcleareddict, orient='index')

    return MTTRnotcleared_df

def mttrcomputationfornotcleared1(conn,start):

    start_time = start
    # end_time = end
    dictCursor = conn.cursor()
    dictCursor.execute(
        """ SELECT 
                    t.ttID AS ttid,
                    m_circle.znZoneID AS znZoneID,
                    m_zone.znZone AS znZone,
                    m_circle.clCircleID AS clCircleID,
                    m_circle.clCircle AS clCircle,
                    m_site.crClusterID AS crClusterID,
                    m_cluster.crName AS crName,
                    m_site.smSiteID AS smSiteID,
                    m_site.smPaceSiteCode AS smPaceSiteCode,
                    m_site.smSiteName AS smSiteName,
                    m_site.pdId AS cmCompanyID,
                    m_sitestatusmaster.ssmStatus AS ssmStatus,
                    t.ttOpenTime AS soStartDateTime,
                    t.ttClearTime AS soRestoreDateTime,
                    t.acAccID AS acAccID,
                    m_site.pdId AS cmCompanyVendorID,
                    t.socID AS socID,
                    t.sofeID AS sofeID,
                    t.ttLastUpdatedDt as ttLastUpdatedDt,
                    t.alID AS alID,
                    m_alarmnames.alName AS alName,
                    m_sitetype.smtTypeID,
                    m_sitetype.smtTypeName,
                    t_visitlog.caID AS caID,
                    m_powerdetails.pdCategory AS pdCategory,
                    m_powerdetails.pdName AS pdName

                    FROM t_troubleticketlog AS t
                      JOIN m_site 
                            ON (t.smSiteID = m_site.smSiteID)
                         JOIN m_alarmnames 
                            ON (t.alID = m_alarmnames.alID)
                         JOIN m_circle 
                            ON (t.clCircleID = m_circle.clCircleID)
                         JOIN m_cluster 
                            ON (m_site.crClusterID = m_cluster.crClusterID)
                         JOIN m_sitestatusmaster 
                            ON (m_site.ssmID = m_sitestatusmaster.ssmID)
                         JOIN m_powerdetails 
                            ON (m_site.pdId = m_powerdetails.pdID) 
                         JOIN m_zone 
                            ON (m_circle.znZoneID = m_zone.znZoneID) 
                         JOIN m_sitetype
                        ON (m_site.smSiteType = m_sitetype.smtTypeID)
                         LEFT JOIN t_visitlog 
                            ON (t.ttID = t_visitlog.ttID)
                   WHERE t.isOutageTT=1  AND t.ttisParent=0 AND t.ttClearTime =0 AND t.ttOpenTime < %s """,
            (start_time))

    columns = [column[0] for column in dictCursor.description]

    resultSet = dictCursor.fetchall()
    results = []

    for row in resultSet:
        results.append(dict(zip(columns, row)))

    nums = [x for x in range(len(results))]

    MTTRnotcleareddict1 = dict(zip(nums, results))
    MTTRnotcleared_df1 = pd.DataFrame.from_dict(MTTRnotcleareddict1, orient='index')

    return MTTRnotcleared_df1

