import datetime
ts = int(datetime.datetime.now().timestamp())
print(ts)