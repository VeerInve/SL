
# python imports
import datetime
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
import sys


# analysis tool imports
import pandas as pd
import numpy as np

# DB related imports
import pymysql
from sqlalchemy import create_engine
from sqlalchemy import MetaData, Column, Table
from sqlalchemy import String ,Date, Float

# package imports
import setting as settings
import databaseRead


now = datetime.now()
scriptRunTime = now.strftime("%Y-%m-%d %H:%M:%S")
print(scriptRunTime)


try:
    conn = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                           user=settings.DATABASE_CONFIG['user'],
                           password=settings.DATABASE_CONFIG['password'],
                           db=settings.DATABASE_CONFIG['database'])

except pymysql.OperationalError:
    sys.exit()
except pymysql.InternalError:
    sys.exit()

try:
    host = settings.DATABASE_CONFIG['host']
    user = settings.DATABASE_CONFIG['user']
    password = settings.DATABASE_CONFIG['password']
    db = settings.DATABASE_CONFIG['database']
    port = settings.DATABASE_CONFIG['port']

    engine = create_engine('mysql+pymysql://' + user + ':' + password + '@' + host + ':' + str(port) + '/' + db,
                           echo=False)
    metadata = MetaData(bind=engine)

except pymysql.OperationalError:
    sys.exit()
except pymysql.InternalError:
    sys.exit()

year = settings.DATE_PARAMS['year']
start_index =  settings.DATE_PARAMS['start_index']
end_index = settings.DATE_PARAMS['end_index']
start_month =  settings.DATE_PARAMS['start_month']
end_month =  settings.DATE_PARAMS['end_month']

print(year)
print(start_index)
print(end_index)
print(start_month)
print(end_month)


if __name__ == '__main__':
    start_date = date(year, start_month, start_index)
    end_date = date(year, end_month, end_index)

    step = timedelta(hours=24)

    while start_date <= end_date:
        b_time_str = str(start_date)

        t_start = " 00:00:00"
        t_end = " 23:59:59"

        start = b_time_str + t_start
        print(start)
        end = b_time_str + t_end
        print(end)

        pattern = '%Y-%m-%d %H:%M:%S'

        start_bound = int(time.mktime(datetime.strptime(start, pattern).timetuple()))
        end_bound = int(time.mktime(datetime.strptime(end, pattern).timetuple()))

        schedulerdate = start_date.strftime(("%Y-%m-%d"))
        print(schedulerdate)

        # Intialize date
        #***************************************
        # day = now.day
        # month = now.month
        # year = now.year
        # currentDate = date(year, month, day)
        #*************************************
        # b_current_start = str(currentDate)
        # t_start_current = " 00:00:00"
        # start_current = b_current_start + t_start_current
        # pattern = '%Y-%m-%d %H:%M:%S'
        # start_day_current = str(datetime.strptime(start_current, pattern))
        # start_bound_current = int(time.mktime(datetime.strptime(start_day_current, pattern).timetuple()))


        ##intialDate = currentDate - timedelta(days=1)
        # intialDate = date(2021,3,18)
        # b_current_start = str(intialDate)
        # t_start_current = " 00:00:00"
        # start_current = b_current_start + t_start_current
        # pattern = '%Y-%m-%d %H:%M:%S'
        # start_day_current = str(datetime.strptime(start_current, pattern))
        # print(start_day_current)
        # print(type(start_day_current))
        # start_bound_current = int(time.mktime(datetime.strptime(start_day_current, pattern).timetuple()))
        # print('&&&&', start_bound_current)

        # t_start = " 00:00:00"
        # t_end = " 23:59:59"
        # start Date with  timedelta 3 -------------------------------------------------------
        # start Date with  timedelta 0 total count-------------------------------------------------------
        # date_0_days_ago = intialDate - timedelta(days=0)
        # # report date string
        # s_date_0_days_ago = date_0_days_ago.strftime("%d-%b")
        # reportDate = date_0_days_ago.strftime("%d-%b-%Y")
        # print(reportDate)
        # schedulerdate = date_0_days_ago.strftime(("%Y-%m-%d"))
        # print(schedulerdate)

        # b_time_str = str(date_0_days_ago)
        # start = b_time_str + t_start
        # end = b_time_str + t_end
        # pattern = '%Y-%m-%d %H:%M:%S'
        # start_day_0 = datetime.strptime(start, pattern)
        # start_bound = int(time.mktime(datetime.strptime(start, pattern).timetuple()))
        # print(start_bound)
        # current_endbound =  int(datetime.now().timestamp())
        # print(current_endbound)
        # end_bound = int(time.mktime(datetime.strptime(end, pattern).timetuple()))
        # print(end_bound)

        """
        Dataset when cleartime is present between scheduler computation date
        """

        MTTRDF = databaseRead.mttrcomputation(conn, start_bound, end_bound)
    
    
        # MTTRDF.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/mttrtest.xlsx')
    
        """
        Filter Data from MTTRDF where cleartime is between processing date
        Case1: when open date is between processing date
        Case2: when open date is before processing date
        """
        MTTRDF1 = MTTRDF.loc[(MTTRDF['soRestoreDateTime'] >= start_bound) & (MTTRDF['soRestoreDateTime'] <= end_bound)]
    
        """ Case1: when open date is between processing date"""

        MTTRDF2 = MTTRDF1.loc[(MTTRDF1['soStartDateTime']>=start_bound) & (MTTRDF1['soStartDateTime'] <= end_bound)]
        # computing Outage Minutes
        MTTRDF2['duration'] = MTTRDF2['soRestoreDateTime'] - MTTRDF2['soStartDateTime']
        MTTRDF2['OutageMinutes'] = MTTRDF2['duration'] / 60
        MTTRDF2['OutageMinutes'] = (MTTRDF2['duration'] / 60).round(5)
        MTTRDF2['totalTime'] = 1440
        # computing Uptime percentage
        MTTRDF2['UptimeMinutes'] = MTTRDF2['totalTime'] - MTTRDF2['OutageMinutes']
        MTTRDF2['Uptimefraction'] = MTTRDF2['UptimeMinutes'] / MTTRDF2['totalTime'] * 100
        MTTRDF2['PercentageUptime'] = (MTTRDF2['Uptimefraction']).round(3)
        MTTRDF2['dummydate'] = MTTRDF2['soStartDateTime']
        MTTRDF2.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/mttruptime1.xlsx')
    
        """ Case2: when open date is before processing date """

        MTTRDF22 = MTTRDF1.loc[(MTTRDF1['soStartDateTime'] < start_bound)]
        # compute Outage Minutes
        MTTRDF22['startticker'] = start_bound
        MTTRDF22['soStartDateTime'] = start_bound
        MTTRDF22['duration'] = MTTRDF22['soRestoreDateTime'] - MTTRDF22['startticker']
        MTTRDF22['OutageMinutes'] = MTTRDF22['duration'] / 60
        MTTRDF22['OutageMinutes'] = (MTTRDF22['duration'] / 60).round(5)
        # computing Uptime percentage
        MTTRDF22['totalTime'] = 1440
        MTTRDF22['UptimeMinutes'] = MTTRDF22['totalTime'] - MTTRDF22['OutageMinutes']
        MTTRDF22['Uptimefraction'] = MTTRDF22['UptimeMinutes'] / MTTRDF22['totalTime'] * 100
        MTTRDF22['PercentageUptime'] = (MTTRDF22['Uptimefraction']).round(3)
        MTTRDF22['dummydate'] = start_bound
        MTTRDF22.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/mttruptime2.xlsx')
    
        """
           Filter Data from MTTRDF where cleartime is ahead processing date and on before scheduler running time
           Case1: when open date is between processing date
           Case2: when open date is before processing date
           Case3: When open date is on Scheduler running date
        """
        '''
        # filter dataframe with cleardate > schduler date
        MTTRDF3 = MTTRDF.loc[(MTTRDF['soRestoreDateTime'] >= end_bound)]
    
        # Case1: when open date is between processing date
        MTTRDF4 = MTTRDF3.loc[(MTTRDF3['soStartDateTime'] >= start_bound) & (MTTRDF3['soStartDateTime'] <= end_bound)]
        MTTRDF4['soRestoreDateTime'] = end_bound
        MTTRDF4['endbound'] = end_bound
        MTTRDF4['duration'] = MTTRDF4['endbound'] - MTTRDF4['soStartDateTime']
        MTTRDF4['OutageMinutes'] = (MTTRDF4['duration'] / 60).round(5)
        #Uptime
        MTTRDF4['totalTime'] = 1440
        MTTRDF4['UptimeMinutes'] = MTTRDF4['totalTime'] - MTTRDF4['OutageMinutes']
        MTTRDF4['Uptimefraction'] = MTTRDF4['UptimeMinutes']/MTTRDF4['totalTime']*100
        MTTRDF4['PercentageUptime'] = (MTTRDF4['Uptimefraction']).round(3)
        MTTRDF4['dummydate'] = start_bound
        # MTTRDF4.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/mttruptime3.xlsx')
    
        # Case2: when open date is before processing date
        MTTRDF5 = MTTRDF3.loc[(MTTRDF3['soStartDateTime'] < start_bound)]
        MTTRDF5['duration'] = 1440
        MTTRDF5['OutageMinutes'] = 1440
        MTTRDF5['soStartDateTime'] = start_bound
        MTTRDF5['soRestoreDateTime'] = end_bound
        # Uptime
        MTTRDF5['totalTime'] = 1440
        MTTRDF5['UptimeMinutes'] = MTTRDF5['totalTime'] - MTTRDF5['OutageMinutes']
        MTTRDF5['Uptimefraction'] = MTTRDF5['UptimeMinutes'] / MTTRDF5['totalTime'] * 100
        MTTRDF5['PercentageUptime'] = (MTTRDF5['Uptimefraction']).round(3)
        MTTRDF5['dummydate'] = start_bound
        # MTTRDF5.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/mttruptime4.xlsx')
        '''
        # concat 3 dataframe
        MTTRDF2 = MTTRDF2[['ttid','znZoneID','znZone','clCircleID','clCircle','crClusterID',
                           'crName','smSiteID','smPaceSiteCode','smSiteName','cmCompanyID',
                           'ssmStatus','soStartDateTime','soRestoreDateTime','OutageMinutes',
                           'PercentageUptime','acAccID','cmCompanyVendorID','socID','sofeID',
                            'ttLastUpdatedDt','alID','alName','smtTypeID','smtTypeName','caID','dummydate'
                        ]]
        MTTRDF22 = MTTRDF22[['ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
                           'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
                           'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
                           'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
                           'ttLastUpdatedDt','alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID','dummydate'
                           ]]
        # MTTRDF4 = MTTRDF4[['ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
        #                    'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
        #                    'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
        #                    'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
        #                    'ttLastUpdatedDt','alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID','dummydate'
        #                    ]]
        # MTTRDF5 = MTTRDF5[['ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
        #                    'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
        #                    'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
        #                    'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
        #                    'ttLastUpdatedDt', 'alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID', 'dummydate'
        #                    ]]
    
    
        """
        Dataset when cleartime is not avialable between processing date
        """
        MTTRDFNotCleared = databaseRead.mttrcomputationfornotcleared(conn, start_bound, end_bound)
        # Outage Minute computation
        MTTRDFNotCleared['soRestoreDateTime'] = end_bound
        MTTRDFNotCleared['endbound'] = end_bound
        MTTRDFNotCleared['duration'] = MTTRDFNotCleared['endbound'] - MTTRDFNotCleared['soStartDateTime']
        MTTRDFNotCleared['OutageMinutes'] = (MTTRDFNotCleared['duration'] / 60).round(5)
        MTTRDFNotCleared['dummydate'] = start_bound
        # Uptime Percentage Computation
        MTTRDFNotCleared['totalTime'] = 1440
        MTTRDFNotCleared['UptimeMinutes'] = MTTRDFNotCleared['totalTime'] - MTTRDFNotCleared['OutageMinutes']
        MTTRDFNotCleared['Uptimefraction'] = MTTRDFNotCleared['UptimeMinutes'] / MTTRDFNotCleared['totalTime'] * 100
        MTTRDFNotCleared['PercentageUptime'] = (MTTRDFNotCleared['Uptimefraction']).round(3)
        MTTRDFNotCleared = MTTRDFNotCleared[['ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
                                             'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
                                             'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
                                             'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
                                             'ttLastUpdatedDt', 'alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID',
                                             'dummydate'
                                             ]]
        # MTTRDFNotCleared.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/notclearedcheck1.xlsx')
    
        # dataset when cleartime is not avialable and opentime is before processing day
        MTTRDFNotCleared1 = databaseRead.mttrcomputationfornotcleared1(conn, start_bound)
        # not clear case
        MTTRDFNotCleared1['soRestoreDateTime'] = end_bound
        MTTRDFNotCleared1['soStartDateTime'] = start_bound
        MTTRDFNotCleared1['OutageMinutes'] = 1440
        MTTRDFNotCleared1['PercentageUptime'] = 0
        MTTRDFNotCleared1['dummydate'] = start_bound
        # MTTRDFNotCleared1.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/notclearedcheckk2.xlsx')
        MTTRDFNotCleared1 = MTTRDFNotCleared1[['ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
                                             'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
                                             'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
                                             'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
                                             'ttLastUpdatedDt', 'alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID','dummydate'
                                             ]]
        # MTTRDFNotCleared1.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/notclearedcheck2.xlsx')
    
        print('*********3')
        dfList = [MTTRDF2,MTTRDF22,MTTRDFNotCleared,MTTRDFNotCleared1]
        final_df = pd.concat(dfList)
        # final_df['ttLastUpdatedDt'] = 0
        final_df['SchedulerRunDate'] = schedulerdate
        final_df['dayAutoID'] = 0
        final_df = final_df[['SchedulerRunDate','ttid', 'znZoneID', 'znZone', 'clCircleID', 'clCircle', 'crClusterID',
                           'crName', 'smSiteID', 'smPaceSiteCode', 'smSiteName', 'cmCompanyID',
                           'ssmStatus', 'soStartDateTime', 'soRestoreDateTime', 'OutageMinutes',
                           'PercentageUptime', 'acAccID', 'cmCompanyVendorID', 'socID', 'sofeID',
                           'ttLastUpdatedDt','alID', 'alName', 'smtTypeID', 'smtTypeName', 'caID','dummydate'
                           ]]
        # change flag for Normal BSC and STRATEGIC BSC
        final_df.replace(to_replace=["Normal BSC", "STRATEGIC BSC"],
                   value="BSC",inplace=True)
        final_df['socID'].fillna(19,inplace = True)
        final_df['sofeID'].fillna(150,inplace = True)
        #final_df.to_excel('D:/Application/aggregator/a_dailyoutagescheduler/data/temp_data/finalcheck.xlsx')
        final_df.to_sql('a_dailyoutage', engine, if_exists='append',index=False)
        print('*********4')


        start_date += step


