import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TTLogComponent } from './ttlog.component';

describe('TTLogComponent', () => {
  let component: TTLogComponent;
  let fixture: ComponentFixture<TTLogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TTLogComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TTLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
