import { Component, ChangeDetectorRef, ViewChild } from "@angular/core";
import { ICellRendererAngularComp } from "@ag-grid-community/angular";
import {
  NgbModal,
  ModalDismissReasons,
  NgbModalConfig,
} from "@ng-bootstrap/ng-bootstrap";

import Swal from "sweetalert2/dist/sweetalert2.js";
import { NgForm } from "@angular/forms";
import {
  ColDef,
  GridReadyEvent,
  GridApi,
  ExcelStyle,
  CellClassParams,
  ColumnApi,
  CellClassRules,
} from "ag-grid-community";
import { DatePipe } from "@angular/common";
import { BindingURLService } from "../../service/Bindingurlservice/binding-url.service";
import { ApiService } from "../../service/apiUrls/apiUrl.service";
import { openModalService } from "../../service/ModalService/ModalService";
import { HttpService } from "../../service/HTTPService/HttpService";
import { Exportclass } from "../../service/ExportService/ExportService";

@Component({
  selector: "app-actions-cell",
  template: `
    <div>
      <div id="loader" [class]="className"></div>
    </div>
    <select
      style="height: 33px;font-size: 13px;width: 96px;margin-top:3px;margin-left:-10px;"
      class="form-control"
      [(ngModel)]="selectedOption"
      (change)="onOptionChange()"
    >
      <option value="" disabled selected>Action</option>
      <option value="assignTTLog">Assign</option>
      <option value="updateTTLogStatus">Status Change</option>
    </select>

    <!-- tt log -->
    <ng-template #AssignTTLog let-modal>
      <div class="modal-header">
        <h4 class="modal-title" id="modal-basic-title">Assign TT Log</h4>
        <button
          type="button"
          class="close"
          aria-label="Close"
          (click)="modal.dismiss('Cross click')"
        >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body UpdateTTModal">
        <form #form="ngForm">
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="ttNumber">TT Number</label>
                <input
                  type="text"
                  class="form-control"
                  id="ttNumber-id"
                  [(ngModel)]="AssignTTNumberBindval"
                  name="ttNumberName"
                  disabled
                />
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label>Site ID | Site Name</label><br />
                <!-- <ng-select
                  [multiple]="false"
                  [virtualScroll]="true"
                  [closeOnSelect]="true"
                  name="sites"
                  class="custom"
                  [items]="searchSite"
                  bindValue="SiteID"
                  bindLabel="siteId_Name"
                  placeholder="Select"
                  [(ngModel)]="assignSiteIdBindval"
                  disabled
                >
                  <ng-template
                    ng-option-tmp
                    let-item="item"
                    let-item$="item$"
                    let-index="index"
                  >
                    {{ item.siteId_Name }}
                  </ng-template>
                </ng-select> -->
                <input
                  type="text"
                  class="form-control"
                  id="siteId_Name"
                  [(ngModel)]="assignSiteIdBindval"
                  name="site_Name"
                  disabled
                />
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label for="engiName" id="required">Engineer Name</label>
                <div>
                  <ng-select
                    [virtualScroll]="true"
                    [multiple]="false"
                    [closeOnSelect]="true"
                    [selectableGroup]="true"
                    [clearable]="false"
                    name="engineerName"
                    class="custom"
                    [items]="usersList"
                    bindValue="ID"
                    bindLabel="UserName"
                    placeholder="Select"
                    [(ngModel)]="engiNameBindVal"
                    required
                    #engiName="ngModel"
                  >
                    <ng-template
                      ng-option-tmp
                      let-item="item"
                      let-item$="item$"
                      let-index="index"
                    >
                      {{ item.UserName }}
                    </ng-template>
                  </ng-select>
                  <div
                    *ngIf="engiName.invalid && engiName.touched"
                    class="error-message"
                  >
                    Engineer Name is Required.
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="actionAdd">Action</label>
                <textarea
                  class="form-control"
                  id="actionDesc"
                  rows="3"
                  [(ngModel)]="actionBindval"
                  name="remark"
                ></textarea>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group">
                <label for="remark">Remark</label>
                <textarea
                  class="form-control"
                  id="remark"
                  rows="3"
                  [(ngModel)]="assignRemark"
                  name="remark"
                ></textarea>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button class="btn btn-outline-primary" (click)="clearAssign()">
              Clear
            </button>
            <button
              class="btn btn-primary"
              (click)="AssignTTLogSubmit()"
              [disabled]="!form.valid"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </ng-template>
    <ng-template #UpdateTTLogStatus let-modal>
      <div class="modal-header">
        <h4 class="modal-title" id="modal-basic-title">Update TT Log Status</h4>
        <button
          type="button"
          class="close"
          aria-label="Close"
          (click)="modal.dismiss('Cross click')"
        >
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body UpdateTTModal">
        <form #form="ngForm">
          <div class="row">
            <div class="col-md-4">
              <div class="form-group">
                <label for="ttNumber">TT Number</label>
                <input
                  type="text"
                  class="form-control"
                  id="ttNumber-id"
                  [(ngModel)]="updateTTNumberBindval"
                  name="ttNumberName"
                  disabled
                />
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>Site ID | Site Name</label><br />
                <!-- <ng-select
                  [multiple]="false"
                  [virtualScroll]="true"
                  [closeOnSelect]="true"
                  name="sites"
                  class="custom"
                  [items]="allSiteLists"
                  bindValue="value"
                  bindLabel="label"
                  placeholder="Select"
                  [(ngModel)]="statChgSelectedSite"
                  disabled
                >
                  <ng-template
                    ng-option-tmp
                    let-item="item"
                    let-item$="item$"
                    let-index="index"
                  >
                    {{ item.label }}
                  </ng-template>
                </ng-select> -->
                <input
                  type="text"
                  class="form-control"
                  id="sites-id"
                  [(ngModel)]="statChgSelectedSite"
                  name="sites"
                  disabled
                />
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="status">Current Status</label>
                <!-- <ng-select
                  class="custom-dropdown"
                  [virtualScroll]="true"
                  [multiple]="false"
                  [clearable]="false"
                  name="crntStatusName"
                  class="custom"
                  [items]="ttStatusList"
                  bindValue="value"
                  bindLabel="label"
                  placeholder="Select"
                  [(ngModel)]="statusBindval"
                  disabled
                >
                  <ng-template
                    ng-option-tmp
                    let-item="item"
                    let-item$="item$"
                    let-index="index"
                  >
                    {{ item.label }}
                  </ng-template>
                </ng-select> -->
                <input
                  type="text"
                  class="form-control"
                  id="status-id"
                  [(ngModel)]="statusBindval"
                  name="crntstatus"
                  disabled
                />
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="status" id="required">New Status</label>
                <ng-select
                  class="custom-dropdown"
                  [virtualScroll]="true"
                  [multiple]="false"
                  [clearable]="false"
                  name="newStatusName"
                  class="custom"
                  [items]="ttStatusList"
                  bindValue="value"
                  bindLabel="label"
                  placeholder="Select"
                  [(ngModel)]="newStatusBindval"
                  required
                  #newStatus="ngModel"
                >
                  <ng-template
                    ng-option-tmp
                    let-item="item"
                    let-item$="item$"
                    let-index="index"
                  >
                    {{ item.label }}
                  </ng-template>
                </ng-select>
                <div
                  *ngIf="newStatus.invalid && newStatus.touched"
                  class="error-message"
                >
                  New Status is Required.
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="engiName">Closed By</label>
                <div>
                  <ng-select
                    [virtualScroll]="true"
                    [multiple]="false"
                    [closeOnSelect]="true"
                    [selectableGroup]="true"
                    name="engineerName"
                    class="custom"
                    [items]="usersList"
                    bindValue="ID"
                    bindLabel="UserName"
                    placeholder="Select"
                    [(ngModel)]="ticketClosedBy"
                  >
                    <ng-template
                      ng-option-tmp
                      let-item="item"
                      let-item$="item$"
                      let-index="index"
                    >
                      {{ item.UserName }}
                    </ng-template>
                  </ng-select>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label for="closeTime">Close Time</label>
                <input
                  type="datetime-local"
                  step="1"
                  [max]="maxDateTime"
                  class="form-control"
                  id="dateRange6"
                  name="dateTime6"
                  [(ngModel)]="ttTicketCloseTime"
                  (change)="onOpenTimeChange($event)"
                />
              </div>
            </div>

            <div class="col-md-12">
              <div class="form-group">
                <label for="remark">Remark</label>
                <textarea
                  class="form-control"
                  id="remark"
                  rows="3"
                  [(ngModel)]="statusRemark"
                  name="remark"
                ></textarea>
              </div>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button class="btn btn-outline-primary" (click)="clearStatus()">
          Clear
        </button>
        <button
          class="btn btn-primary"
          (click)="TTLogStatusUpdate()"
          [disabled]="!form.valid"
        >
          Submit
        </button>
      </div>
    </ng-template>
  `,
  styles: [
    `
      .btn {
        margin-right: 5px;
      }
    `,
  ],
})
export class ActionRendererComponent implements ICellRendererAngularComp {
  timeZoneName: "";
  corporateName: string;
  applicationTitle: string = "";
  supportEmail: string;
  defaultCountryCode: string;

  datetimeFormat: string = "dd-MM-yyyy,hh:mm:ss";
  // timeFormat: string = '';
  alarmDisplayMode: string = "";
  alarmHistoryDays: string;
  refreshInterval: string = "";
  recordsPerPage: any;
  countryLatitude: number;
  countryLongitude: number;
  initialMapZoomLevel: string = "";
  distanceUnit: number;
  deviceLastUpdate: string = "30";
  gridPowerAlarmDayBuffer: string;
  gridPowerAlarmPercentageBuffer: string;
  gridPowerAlarmMinuteBuffer: string;
  genMaintainFrequency: string;
  genMaintainHours: string;
  genMaintainThreshold: string;
  gridPowerPaymentDue: string;
  siteOutageDataEntry: string;
  alarmEscalationDuration: string;
  gridPowerAlarmDuration: string;
  outageThresholdDuration: string = "";
  lowVoltageDuration: string;
  consistentLowVoltage: string;
  serviceCharge: string;
  vat: string;
  gvS: string;
  streetLT: string;
  ttLogPrefix: string;
  pmLogPrefix: string;

  genMaintainPrefix: string;

  visitLogOnCallPrefix: string;
  cCheckTopOverhaul: string;
  majorOverhaul: string;
  topOverhaulGenMaintainCount: string;
  majorOverhaulGenMaintainCount: string;
  genMaintainFreeze: string;
  // AddandEdit = 'Add UserGroup';
  Addvendorapi = "UserGroup/add-new-UserGroup";
  className = "";
  usergorupid = 0;
  numbers: number[] = Array.from({ length: 15 }, (_, i) => i + 1);
  intialzoom: number[] = Array.from({ length: 13 }, (_, i) => i + 5);
  AddandEditApiurl = "UserGroup/add-new-UserGroup";
  resp = "";
  modeldata;
  timezonelist;
  selectedFile: File | null;
  imagePreview: string | ArrayBuffer | null;
  base64Image;
  maxSizeInBytes = 1024 * 1024;
  acpEBPaymentDue;
  acpInitialZoom;
  acpDistnceUnit;
  acpOutageDays;
  acpEBAlarmFailureDays;
  acpBCheckThreshold;
  acpEBLogAlarmDuration;

  // className = '';
  selectedOption: string = "";
  closeResult: string;
  params: any;
  disableclear: boolean = false;
  AddandEdit = "Update UserGroup";
  // datetimeFormat: string = '';
  // timeFormat: string = '';
  featureName: string = "";
  // deviceLastUpdate: number;
  @ViewChild("AssignTTLog") AssignTTLog: any;
  @ViewChild("accountFeaturesModal") accountFeaturesModal: any;
  @ViewChild("UpdateTTLogStatus") UpdateTTLogStatus: any;
  @ViewChild("tableConfigModal") tableConfigModal;
  // usergorupid;
  acAccountId;
  gridPowerAlarmOutageDays;

  //table index variables
  public domLayout: "normal" | "autoHeight" | "print" = "autoHeight";
  public rowSelection: "single" | "multiple" = "multiple";
  reportRecords = [
    { id: "10", value: "10" },
    { id: "20", value: "20" },
    { id: "50", value: "50" },
    { id: "100", value: "100" },
  ];
  public paginationPageSize = 10;
  public defaultColDef: ColDef = {
    cellClassRules: {
      darkGreyBackground: (params: CellClassParams) => {
        return (params.node.rowIndex || 0) % 2 == 0;
      },
    },
    flex: 1,
    minWidth: 120,
    resizable: true,
    enableValue: true,
    enableRowGroup: true,
    enablePivot: true,
    sortable: true,
    wrapText: true,
    filter: true,
    wrapHeaderText: true,
    autoHeaderHeight: true,
  };
  public columnDefs: ColDef[];
  public rowData!: any[];
  public gridData: any[] = [];
  public headers: any;
  private gridApi!: GridApi;
  gridOptions;
  public colResizeDefault: "shift" = "shift";
  private gridColumnApi!: ColumnApi;
  recordsize = 10;
  public excelStyles: ExcelStyle[] = [
    {
      id: "dateLong",
      dataType: "DateTime",
      numberFormat: {
        format: "dd/mm/yyy hh:mm:ss",
      },
    },
    {
      id: "greenBackground",
      interior: {
        color: "#b5e6b5",
        pattern: "Solid",
      },
    },
    {
      id: "redFont",
      font: {
        fontName: "Calibri Light",
        underline: "Single",
        italic: true,
        color: "#ff0000",
      },
    },
    // {
    //   id: "darkGreyBackground",
    //   interior: {
    //     color: "#888888",
    //     pattern: "Solid",
    //   },
    //   font: {
    //     fontName: "Calibri Light",
    //     color: "#ffffff",
    //   },
    // },
    {
      id: "boldBorders",
      borders: {
        borderBottom: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
        borderLeft: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
        borderRight: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
        borderTop: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
      },
    },
    {
      id: "header",
      font: { size: 14 },
      interior: {
        color: "#b5e6b5",
        pattern: "Solid",
      },
      borders: {
        borderBottom: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
        borderLeft: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
        borderRight: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
        borderTop: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
      },
    },
    {
      id: "bigHeader",
      interior: {
        color: "#519d43",
        pattern: "Solid",
      },

      font: { size: 18, color: "#ffffff" },
      alignment: {
        horizontal: "Center",
        vertical: "Center",
      },
    },
  ];
  enableAddTableIndex = false;
  tableIndexAutoId = 0;
  tableIndexAddandEdit = "Add Table Index";
  tableIndexGridData;
  frameworkComponents;
  siteCodeName;
  mtrRefTypeBindVal;
  mtrSlaveIdBindVal;
  displayStyle;
  mtrNameBindVal;
  tableIndexBindVal;
  effectFromTime;
  AccountStatus: number | null = 1;
  AccountStatusId;
  inActivedisable: boolean = false;
  Activedisable: boolean = false;
  years: number[] = [];
  selectedYear: number | null = null;

  // ttlog variables
  updateTTNumberBindval;
  ttTicketCloseTime;
  statChgSelectedSite;
  statusBindval = [];
  newStatusBindval = [];
  ticketClosedBy = [];
  statusRemark;
  TTLogStatusLists = [
    {
      name: "Dispatched",
      id: 1,
    },
    {
      name: "Accepted",
      id: 2,
    },
    {
      name: "Travel",
      id: 3,
    },
    {
      name: "WIP",
      id: 4,
    },
    {
      name: "WES",
      id: 5,
    },
    {
      name: "WIS",
      id: 6,
    },
    {
      name: "Rejected",
      id: 7,
    },
    {
      name: "Out Of Scope",
      id: 8,
    },
    {
      name: "Cancelled",
      id: 9,
    },
  ];
  searchSite = [];
  searchRegion = [];
  selectedRegion;
  closeTimeMin: string = "";
  maxDateTime: string = "";
  AssignTTNumberBindval;
  assignSiteIdBindval;
  engiNameBindVal;
  actionBindval;
  assignRemark;
  ttStatusList = [];
  allSiteLists = [];
  usersList = [];
  constructor(
    private modalService: NgbModal,
    config: NgbModalConfig,
    private modelservice: openModalService,
    private http: HttpService,
    private apiUrl: ApiService,
    private Exportdata: Exportclass,
    private datePipe: DatePipe,
    private urlAuthentication: BindingURLService
  ) {
    this.frameworkComponents = {
      //   editCell: InventoryEditBtnComponent,
    };

    const currentYear = new Date().getFullYear();
    this.years = [currentYear - 1, currentYear, currentYear + 1];
    this.selectedYear = currentYear;
  }

  ngOnInit() {
    // this.getTableIndexGridData();
    this.allDropdownDatas();
    this.setMinMaxDateTime();
  }

  agInit(params: any): void {
    this.params = params;
    this.acAccountId = this.params.data.acAccID;
    // this.getAccountPrefData();
  }

  allDropdownDatas() {
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getTTStatus, {})
      .subscribe((resp) => {
        this.ttStatusList = [];
        this.ttStatusList = resp.response;
      });
    // this.http
    //   .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getSites, {})
    //   .subscribe((resp) => {
    //     this.allSiteLists = [];
    //     this.allSiteLists = resp.response;
    //   });
    this.http
      .post(this.urlAuthentication.newMastersUrl + this.apiUrl.getUsers, {})
      .subscribe((resp) => {
        this.usersList = [];
        this.usersList = resp.response;
      });
  }

  onOptionChange(): void {
    if (this.selectedOption === "assignTTLog") {
      this.clearAssign();
      //   this.getAccountPrefData();
      this.openModal(this.AssignTTLog);
    } else if (this.selectedOption === "updateTTLogStatus") {
      this.openModal(this.UpdateTTLogStatus);
      this.clearStatus();
    }
  }

  openModal(content: any) {
    this.modalService
      .open(content, { size: "lg", backdrop: "static" })
      .result.then(
        () => this.resetDropdown(),
        () => this.resetDropdown()
      );
  }

  resetDropdown() {
    this.selectedOption = "";
  }

  refresh(): boolean {
    return false;
  }

  openSearchModal(tableConfigModal) {
    this.disableclear = false;
    this.modelservice.OpenModel(this.tableConfigModal, "sm");
  }

  //table index methods
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    // this.autoSizeAll(true)
    this.Exportdata.setSharedVariable(params);
  }
  onPageSizeChanged(e) {
    let _v = e.target.value;
    const value = _v;
    this.gridApi.paginationSetPageSize(Number(value));
  }
  onSelectionChanged(e) {
    let rowsSelection = this.gridApi.getSelectedRows();
  }

  autoSizeAll(skipHeader: boolean) {
    const allColumnIds: string[] = [];
    this.gridColumnApi.getColumns()!.forEach((column) => {
      allColumnIds.push(column.getId());
    });
    this.gridColumnApi.autoSizeColumns(allColumnIds, skipHeader);
  }

  ragCellClassRules: CellClassRules = {
    "rag-green-text": (params) => params.value === 1,
    "rag-red-text": (params) => params.value === 0,
  };
  setMinMaxDateTime(): void {
    const now = new Date();
    this.maxDateTime = this.formatDatetoT(now);
  }
  formatDatetoT(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  }
  onOpenTimeChange(event: any): void {
    const selectedOpenTime = new Date(event.target.value);
    const minTime = new Date(selectedOpenTime.getTime() + 1000);
    this.closeTimeMin = this.formatDatetoT(minTime);
  }
  clearStatus() {
    // this.statChgSelectedSite = "";
    this.newStatusBindval = [];
    // this.statusBindval = [];
    this.statusRemark = "";
    this.ticketClosedBy = [];
    this.ttTicketCloseTime = "";
  }
  clearAssign() {
    // this.AssignTTNumberBindval = "";
    // this.assignSiteIdBindval = "";
    this.assignRemark = "";
    this.engiNameBindVal = [];
    this.actionBindval = "";
  }
}
