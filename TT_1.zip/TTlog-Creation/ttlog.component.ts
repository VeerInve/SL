import { Component, ViewChild } from "@angular/core";
import {
  ColDef,
  GridReadyEvent,
  GridApi,
  ExcelStyle,
  CellClassParams,
  ColumnApi,
} from "ag-grid-community";
import { TTLogAssignComponent } from "./Assign.component";
import { ApiService } from "../../service/apiUrls/apiUrl.service";
import { DatePipe } from "@angular/common";
import { Router } from "@angular/router";
import { BindingURLService } from "../../service/Bindingurlservice/binding-url.service";
import { HttpService } from "../../service/HTTPService/HttpService";
import { editButtonCellRendererComponent } from "./editTTLog.component";
import { openModalService } from "../../service/ModalService/ModalService";
import { NgbModal, ModalDismissReasons } from "@ng-bootstrap/ng-bootstrap";

import Swal from "sweetalert2";
import { NgForm } from "@angular/forms";
import { TTLogCloseTicketComponent } from "./closeTicket.component";
import { TTLogStatusChangeComponent } from "./StatusChange.component copy";
import { ActionRendererComponent } from "./ttlogActions.component";
@Component({
  selector: "app-ttlog",
  templateUrl: "./ttlog.component.html",
  styleUrls: ["./ttlog.component.css"],
})
export class TTLogComponent {
  @ViewChild("addAndUpdateTTLog") addAndUpdateTTLog;
  @ViewChild("content") content;
  @ViewChild("UpdateTTLogStatus") UpdateTTLogStatus;
  @ViewChild("AssignTTLog") AssignTTLog;
  @ViewChild("ttCloseTicket") ttCloseTicket;
  public domLayout: "normal" | "autoHeight" | "print" = "autoHeight";
  public rowSelection: "single" | "multiple" = "multiple";
  reportRecords = [
    { id: "10", value: "10" },
    { id: "20", value: "20" },
    { id: "50", value: "50" },
    { id: "100", value: "100" },
  ];
  public paginationPageSize = 10;
  public defaultColDef: ColDef = {
    cellClassRules: {
      darkGreyBackground: (params: CellClassParams) => {
        return (params.node.rowIndex || 0) % 2 == 0;
      },
    },
    flex: 1,
    minWidth: 120,
    resizable: true,
    enableValue: true,
    enableRowGroup: true,
    enablePivot: true,
    sortable: true,
    wrapText: true,
    filter: true,
    wrapHeaderText: true,
    autoHeaderHeight: true,
  };
  public columnDefs: ColDef[];
  public rowData!: any[];
  public gridData: any[] = [];
  public headers: any;
  private gridApi!: GridApi;
  gridOptions;
  public colResizeDefault: "shift" = "shift";
  private gridColumnApi!: ColumnApi;
  recordsize = 10;
  public excelStyles: ExcelStyle[] = [
    {
      id: "dateLong",
      dataType: "DateTime",
      numberFormat: {
        format: "dd/mm/yyy hh:mm:ss",
      },
    },
    {
      id: "greenBackground",
      interior: {
        color: "#b5e6b5",
        pattern: "Solid",
      },
    },
    {
      id: "redFont",
      font: {
        fontName: "Calibri Light",
        underline: "Single",
        italic: true,
        color: "#ff0000",
      },
    },
    // {
    //   id: "darkGreyBackground",
    //   interior: {
    //     color: "#888888",
    //     pattern: "Solid",
    //   },
    //   font: {
    //     fontName: "Calibri Light",
    //     color: "#ffffff",
    //   },
    // },
    {
      id: "boldBorders",
      borders: {
        borderBottom: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
        borderLeft: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
        borderRight: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
        borderTop: {
          color: "#000000",
          lineStyle: "Continuous",
          weight: 3,
        },
      },
    },
    {
      id: "header",
      font: { size: 14 },
      interior: {
        color: "#b5e6b5",
        pattern: "Solid",
      },
      borders: {
        borderBottom: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
        borderLeft: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
        borderRight: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
        borderTop: {
          color: "#5687f5",
          lineStyle: "Continuous",
          weight: 1,
        },
      },
    },
    {
      id: "bigHeader",
      interior: {
        color: "#519d43",
        pattern: "Solid",
      },

      font: { size: 18, color: "#ffffff" },
      alignment: {
        horizontal: "Center",
        vertical: "Center",
      },
    },
  ];

  siteMasterGridData;
  frameworkComponents;
  disableclear = false;
  AddandEdit = "Add Ticket";
  className = "";
  TTLogStatusLists = [
    {
      name: "Dispatched",
      id: 1,
    },
    {
      name: "Accepted",
      id: 2,
    },
    {
      name: "Travel",
      id: 3,
    },
    {
      name: "WIP",
      id: 4,
    },
    {
      name: "WES",
      id: 5,
    },
    {
      name: "WIS",
      id: 6,
    },
    {
      name: "Rejected",
      id: 7,
    },
    {
      name: "Out Of Scope",
      id: 8,
    },
    {
      name: "Cancelled",
      id: 9,
    },
  ];
  ttLogGridData;
  siteBindVal;
  customersSiteId;
  siteStatus;
  regionBindVal;
  customerBindval;
  raisedByBindval;
  contactBindval;
  eventBindVal;
  severityBindVal;
  frstPlannedDateBindval;
  remarkBindval;
  outageBindVal;
  faultEquipBindVal;
  ossOpenTimeBindval;
  evtDescBindval;
  assetCatBindVal;
  assetSubCatBindVal;
  partNumBindVal;
  equipSrNoBindVal;
  reportingTimeBindval;
  repContNoBindval;
  repContNameBindval;
  reportEmailIdBindval;
  selectedRegion;
  siteIdBindval;
  siteNameBindval;
  customerNameBindval;
  assignedEngBindval;
  assignedEngiNameBindval;
  ttNumberBindval;
  selectedStatusBindval;
  eventNameBindval;
  vendorBindval;
  startDateBindval;
  endDateBindval;
  AssignTTNumberBindval;
  assignSiteIdBindval;
  assignRemark;
  assignSiteNameBindval;
  engiIdBindVal = [];
  engiNameBindVal = [];
  ttNumber = "";
  disableTTNumDiv: boolean = false;
  siteId;
  siteName;
  siteCode;
  statusBindval = [];
  newStatusBindval;
  statusRemark;
  selectedSite = [];
  searchSite: any[];
  searchRegion: any[];
  accountBindVal = [];
  customerBindVal;
  TTNUmber;
  raisedByNames = [];
  ttOpenTimeBindVal;
  ttCloseTime;
  maxDateTime: string = "";
  closeTimeMin: string = "";
  AssignedBindVal;
  assignStatusBindval;
  addRemarksBindval;
  actionBindval;
  events = [
    {
      name: "Analysis",
      resourceNameBindval: [],
      efforts: "",
      startDate: "",
      endDate: "",
    },
    {
      name: "Development",
      resourceNameBindval: [],
      efforts: "",
      startDate: "",
      endDate: "",
    },
    {
      name: "Review and Unit Test",
      resourceNameBindval: [],
      efforts: "",
      startDate: "",
      endDate: "",
    },
    {
      name: "QA",
      resourceNameBindval: [],
      efforts: "",
      startDate: "",
      endDate: "",
    },
    {
      name: "Release",
      resourceNameBindval: [],
      efforts: "",
      startDate: "",
      endDate: "",
    },
    {
      name: "Close",
      resourceNameBindval: [],
      efforts: "",
      startDate: "",
      endDate: "",
    },
  ];

  tableResource;
  tableStartDate;
  tableEndDate;
  resourceNames = [
    {
      ID: 2,
      UserName: "Umesh",
      LoginName: "Umesh",
    },
    {
      ID: 3,
      UserName: "Sagar",
      LoginName: "Sagar",
    },
    {
      ID: 5,
      UserName: "Mani",
      LoginName: "manideep",
    },
    {
      ID: 57,
      UserName: "mahesh",
      LoginName: "Mahesh",
    },
    {
      ID: 68,
      UserName: "Omee",
      LoginName: "Omee1",
    },
    {
      ID: 78,
      UserName: "InvDev",
      LoginName: "InvDev",
    },
    {
      ID: 90,
      UserName: "AdithiPadaki123",
      LoginName: "Adithipadaki",
    },
    {
      ID: 91,
      UserName: "Pranav",
      LoginName: "Pranav",
    },
    {
      ID: 92,
      UserName: "Channaveer",
      LoginName: "Channaveer",
    },
    {
      ID: 94,
      UserName: "Sonika",
      LoginName: "Sonika",
    },
    {
      ID: 103,
      UserName: "Mahesh",
      LoginName: "Mahi",
    },
  ];
  resourceNameBindval;
  appBindVal;
  departmentBindVal;
  closedByBindVal;
  statChgSelectedSite;
  ReportingNameBindval;
  ReportingTime;
  SeverityBindval;
  priorityBindval;
  prioritylist: any = [
    {
      ID: 1,
      Name: "P1",
    },
    {
      ID: 2,
      Name: "P2",
    },
    {
      ID: 3,
      Name: "P3",
    },
    {
      ID: 4,
      Name: "P4",
    },
    {
      ID: 5,
      Name: "P5",
    },
    {
      ID: 6,
      Name: "P6",
    },
  ];
  severitylist: any = [
    {
      ID: 1,
      Name: "Minor",
    },
    {
      ID: 2,
      Name: "Major",
    },
    {
      ID: 3,
      Name: "Critical",
    },
    {
      ID: 4,
      Name: "Normal",
    },
    {
      ID: 5,
      Name: "Emergency",
    },
    {
      ID: 6,
      Name: "Planned",
    },
  ];
  ttTicketCloseTime;
  closeTicketRemark;
  ticketClosedBy;
  accountList = [];
  severityList = [];
  customerList = [];
  ttStatusList = [];
  usersList = [];
  departmentList = [];
  allSiteLists = [];
  AddCountry;
  AddZone;
  AddRegion;
  AddCluster;
  countryList = [];
  zoneList = [];
  regionList = [];
  clusterlist = [];
  countryName;
  zoneIDs: any = [];
  countryIDs: any = [];
  clusterIDs: any = [];
  regionIDs: any = [];
  zoneName;
  regionName;
  clusterName;
  clusterId = [];
  searchCountry;
  SearchZone;
  searchRegionBindval;
  searchCluster;
  countryType = 0;
  Zonetype = 0;
  CircleType = 0;
  clustertype = 0;
  sitetype = 0;
  appLists = [];
  autoTTId = 0;
  showGridLoader: boolean = false;
  priorityName;
  accountName;
  appName;
  customerName;
  departmentName;
  statusName;
  raisedByName;
  assignedToName;
  severityName;
  ttGridHeaders;
  constructor(
    private http: HttpService,
    private modalService: NgbModal,
    private urlAuthentication: BindingURLService,
    // private eventService: EventService,
    private router: Router,
    private datePipe: DatePipe,
    private apiUrl: ApiService,
    private Modelservice: openModalService
  ) {
    this.frameworkComponents = {
      assignAction: TTLogAssignComponent,
      editCell: editButtonCellRendererComponent,
      statusChangeAction: TTLogStatusChangeComponent,
      closeTicketAction: TTLogCloseTicketComponent,
      actionRenderer: ActionRendererComponent,
    };
  }
  ngOnInit() {
    this.showGridLoader = true;
    this.getTTLogGridData();
    this.allDropdownDatas();
    this.setMinMaxDateTime();
  }

  setMinMaxDateTime(): void {
    const now = new Date();
    this.maxDateTime = this.formatDatetoT(now);
  }
  formatDatetoT(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const hours = String(date.getHours()).padStart(2, "0");
    const minutes = String(date.getMinutes()).padStart(2, "0");
    const seconds = String(date.getSeconds()).padStart(2, "0");

    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
  }
  onOpenTimeChange(event: any): void {
    console.log("ttOpenTimeBindVal", this.ttOpenTimeBindVal);
    const selectedOpenTime = new Date(event.target.value);
    const minTime = new Date(selectedOpenTime.getTime() + 1000);
    this.closeTimeMin = this.formatDatetoT(minTime);
  }

  allDropdownDatas() {
    const siteRequest = {
      fmID: 10000,
    };
    this.http
      .genericApi(this.urlAuthentication.genericApiUrl, siteRequest)
      .subscribe(
        (resp) => {
          this.searchSite = resp.response[0].Data;
          this.searchSite.map((i) => {
            i.siteId_Name = i.SiteCode + " | " + i.SiteName;
            return i;
          });

          this.selectedSite = this.selectedSite;
        },
        (error) => {
          console.error(error);
        }
      );
    const regionReq = {
      fmID: 10002,
    };
    this.http
      .genericApi(this.urlAuthentication.genericApiUrl, regionReq)
      .subscribe(
        (resp) => {
          this.searchRegion = [];
          this.searchRegion = resp.response[0].Data;
          let regionList = resp.response[0].Data;
          this.searchRegion = regionList.filter(
            (item) => item.RegionID && item.RegionName
          );
          const regid = this.selectedRegion;
          const index = this.searchRegion.findIndex(function (item) {
            return item["RegionID"] == regid;
          });
          // if (index > -1) {
          //   this.selectedRegion.push(this.searchRegion[index]["RegionID"]);
          // }
        },
        (error) => {
          console.error(error);
        }
      );
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getApplication, {})
      .subscribe((resp) => {
        this.appLists = [];
        this.appLists = resp.response;
        console.log("App response", resp);
      });

    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getAccount, {})
      .subscribe((resp) => {
        this.accountList = [];
        this.accountList = resp.response;
      });
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getSeverity, {})
      .subscribe((resp) => {
        this.severityList = [];
        this.severityList = resp.response;
      });
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getCompany, {})
      .subscribe((resp) => {
        this.customerList = [];
        this.customerList = resp.response;
      });
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getTTStatus, {})
      .subscribe((resp) => {
        this.ttStatusList = [];
        this.ttStatusList = resp.response;
        console.log("TTStatus response", resp);
      });
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.getDepartments, {})
      .subscribe((resp) => {
        this.departmentList = [];
        this.departmentList = resp.response;
      });
    this.http
      .post(this.urlAuthentication.newMastersUrl + this.apiUrl.getUsers, {})
      .subscribe((resp) => {
        this.usersList = [];
        this.usersList = resp.response;
      });
    this.http
      .post(
        this.urlAuthentication.independentTabUrl + this.apiUrl.getCountry,
        {}
      )
      .subscribe((res) => {
        this.countryList = [];
        this.countryList = res.response;
        // this.selectAllForDropdownItems(this.countryList);
      });
    this.http
      .post(this.urlAuthentication.independentTabUrl + this.apiUrl.getZone, {})
      .subscribe((res) => {
        let zoneinfo = res.response;
        this.zoneList = zoneinfo;
        // this.selectAllForDropdownItems(this.zoneList);
      });

    this.http
      .post(
        this.urlAuthentication.independentTabUrl + this.apiUrl.getRegion,
        {}
      )
      .subscribe((res) => {
        let regionlist = res.response;
        this.regionList = regionlist;

        // this.selectAllForDropdownItems(this.regionList);
      });
    this.http
      .post(
        this.urlAuthentication.independentTabUrl + this.apiUrl.getCluster,
        {}
      )
      .subscribe((res) => {
        let clusterlist = res.response;
        this.clusterlist = clusterlist;

        // this.selectAllForDropdownItems(this.clusterlist);
      });
    this.http
      .post(this.urlAuthentication.newMastersUrl + this.apiUrl.getSiteInfo, {})
      .subscribe((res) => {
        this.allSiteLists = [];
        let sitelists = res.response;
        this.allSiteLists = sitelists;
        // this.selectSiteDropdown(this.allSiteLists);
      });
  }
  getZoneList(countryIDs) {
    this.regionList = [];
    this.zoneList = [];
    // this.AddCountry = ids;
    let json = {
      CountryIDs: countryIDs.toString().replace(/[\[\]']+/g, '"'),
    };
    // Zone
    this.http
      .post(
        this.urlAuthentication.independentTabUrl + this.apiUrl.getZone,
        json
      )
      .subscribe(
        (res) => {
          this.zoneList = [];
          this.zoneList = res.response;
          // this.selectAllForDropdownItems(this.zoneList);
        },
        (error) => {
          this.className = "";
          console.error(error);
        }
      );
  }
  getRegionList(countryIds, zoneIds) {
    this.regionList = [];
    this.clusterlist = [];
    // this.AddZone = ids;
    let json = {
      CountryIDs: countryIds
        ? countryIds.toString().replace(/[\[\]']+/g, '"')
        : "",
      ZoneIDs: zoneIds ? zoneIds.toString().replace(/[\[\]']+/g, '"') : "",
    };
    // Region
    this.http
      .post(
        this.urlAuthentication.independentTabUrl + this.apiUrl.getRegion,
        json
      )
      .subscribe(
        (res) => {
          this.regionList = [];
          this.regionList = res.response;
          // this.selectAllForDropdownItems(this.regionList);
        },
        (error) => {
          this.className = "";
          console.error(error);
        }
      );
  }
  getClusterList(countryIds, zoneIds, regionIds) {
    //cluster ddl AddRegion
    this.clusterlist = [];
    // this.AddRegion = ids;
    let json = {
      CountryIDs: countryIds
        ? countryIds.toString().replace(/[\[\]']+/g, '"')
        : "",
      ZoneIDs: zoneIds ? zoneIds.toString().replace(/[\[\]']+/g, '"') : "",
      CircleIDs: regionIds
        ? regionIds.toString().replace(/[\[\]']+/g, '"')
        : "",
    };
    this.http
      .post(
        this.urlAuthentication.independentTabUrl + this.apiUrl.getCluster,
        json
      )
      .subscribe(
        (res) => {
          this.clusterlist = [];
          this.clusterlist = res.response;
          // this.selectAllForDropdownItems(this.clusterlist);
        },
        (error) => {
          this.className = "";
          console.error(error);
        }
      );
  }
  getsitelist(countryIds, zoneIds, regionIds, clusterIDs) {
    let json = {
      CountryIDs: !countryIds
        ? ""
        : countryIds.toString().replace(/[\[\]']+/g, '"'),
      ZoneIDs: !zoneIds ? "" : zoneIds.toString().replace(/[\[\]']+/g, '"'),
      CircleIDs: !regionIds
        ? ""
        : regionIds.toString().replace(/[\[\]']+/g, '"'),
      ClusterIDs: !clusterIDs
        ? ""
        : clusterIDs.toString().replace(/[\[\]']+/g, '"'),
      // TenantIDs: !this.tenantIDs
      //   ? ""
      //   : this.tenantIDs.toString().replace(/[\[\]']+/g, '"'),
    };
    this.http
      .post(
        this.urlAuthentication.newMastersUrl + this.apiUrl.getSiteInfo,
        json
      )
      .subscribe((res) => {
        let sitelist = res.response;
        this.allSiteLists = sitelist;
        // this.selectSiteDropdown(this.allSiteLists);
      });
  }

  onCountryChange(e) {
    if (!this.AddCountry) {
      this.SearchZone = [];
      this.searchCluster = [];
      this.searchRegionBindval = [];
      this.selectedSite = [];
      // this.clustertype = 0;
      this.zoneList = [];
      this.regionList = [];
      this.clusterlist = [];
      this.allSiteLists = [];
      let selectedCn = this.searchCountry;
      let selectedIds = selectedCn.toString().replace(/[\[\]']+/g, '"');
      // if (str1 == "Select All") {
      //   this.countryIDs = this.countryList.map((country) => country.ID);
      //   this.countryType = 1;
      // } else {
      //   this.countryIDs = selectall;
      //   this.countryType = 2;
      // }
      this.getZoneList(selectedIds);
      this.getRegionList(selectedIds, "");
      this.getClusterList(selectedIds, "", "");
      this.getsitelist(selectedIds, "", "", "");
    } else {
      this.countryName = "";
      this.countryName = e?.Name;
      this.AddZone = [];
      this.AddRegion = [];
      this.AddCluster = [];
      this.clusterlist = [];
      this.siteBindVal = [];
      this.getZoneList(this.AddCountry);
      this.getRegionList(this.AddCountry, "");
      this.getClusterList(this.AddCountry, "", "");
      this.getsitelist(this.AddCountry, "", "", "");
    }
  }
  onZoneChange(e) {
    if (!this.AddZone) {
      this.searchCluster = [];
      this.searchRegionBindval = [];
      this.selectedSite = [];
      this.regionList = [];
      this.clusterlist = [];
      this.allSiteLists = [];
      let selectedZn = this.SearchZone;
      let selectedIds = selectedZn.toString().replace(/[\[\]']+/g, '"');
      // if (str1 == "Select All") {
      //   this.zoneIDs = this.zoneList.map((zone) => zone.ID);
      //   this.Zonetype = 1;
      // } else {
      //   this.zoneIDs = selectall;
      //   this.Zonetype = 2;
      // }
      this.getRegionList(this.searchCountry, selectedIds);
      this.getClusterList(this.searchCountry, selectedIds, "");
      this.getsitelist(this.searchCountry, selectedIds, "", "");
    } else {
      this.zoneName = "";
      this.zoneName = e?.Name;
      this.AddRegion = [];
      this.AddCluster = [];
      this.siteBindVal = [];
      this.getRegionList(this.AddCountry, this.AddZone);
      this.getClusterList(this.AddCountry, this.AddZone, "");
      this.getsitelist(this.AddCountry, this.AddZone, "", "");
    }
  }
  onRegionChange(e) {
    if (!this.AddRegion) {
      this.searchCluster = [];
      this.selectedSite = [];
      this.clusterlist = [];
      this.allSiteLists = [];
      let selectedReg = this.searchRegionBindval;
      let selectedIds = selectedReg.toString().replace(/[\[\]']+/g, '"');
      // if (str1 == "Select All") {
      //   this.regionIDs = this.regionList.map((region) => region.ID);
      //   this.CircleType = 1;
      // } else {
      //   this.regionIDs = this.searchRegionBindval;
      //   this.CircleType = 2;
      // }
      this.getClusterList(this.searchCountry, this.SearchZone, selectedIds);
      this.getsitelist(this.searchCountry, this.SearchZone, selectedIds, "");
    } else {
      this.regionName = "";
      this.regionName = e?.Name;
      this.AddCluster = [];
      this.clusterlist = [];
      this.siteBindVal = [];
      this.getClusterList(this.AddCountry, this.AddZone, this.AddRegion);
      this.getsitelist(this.AddCountry, this.AddZone, this.AddRegion, "");
    }
  }
  onClusterChange(e) {
    if (!this.AddCluster) {
      this.siteBindVal = [];
      let selectedClust = this.searchCluster;
      let selectedIds = selectedClust.toString();
      this.clusterIDs = [];
      // if (str1 == "Select All") {
      //   this.clusterIDs = this.clusterlist.map((cluster) => cluster.ID);
      //   this.clustertype = 1;
      // } else {
      //   this.clusterIDs = this.searchCluster;
      //   this.clustertype = 2;
      // }
      this.getsitelist(
        this.searchCountry,
        this.SearchZone,
        this.searchRegionBindval,
        selectedIds
      );
    } else {
      this.clusterName = "";
      this.clusterName = e?.Name;
      this.siteBindVal = [];
      this.getsitelist(
        this.AddCountry,
        this.AddZone,
        this.AddRegion,
        this.AddCluster
      );
    }
  }

  onSiteChange(ev) {
    this.siteName = "";
    this.siteCode = "";
    this.siteName = ev?.smSiteName;
    this.siteCode = ev?.smSiteCode;
  }

  accountChange(ev) {
    this.accountName = "";
    this.accountName = ev?.label;
  }

  appChange(ev) {
    this.appName = "";
    this.appName = ev?.label;
  }

  customerChange(ev) {
    this.customerName = "";
    this.customerName = ev?.label;
  }
  departmentChange(ev) {
    this.departmentName = "";
    this.departmentName = ev?.label;
  }
  raisedByChange(ev) {
    this.raisedByName = "";
    this.raisedByName = ev?.UserName;
  }
  AssignedToChange(ev) {
    this.assignedToName = "";
    this.assignedToName = ev?.UserName;
  }
  StatusChange(ev) {
    this.statusName = "";
    this.statusName = ev?.label;
  }

  SeverityChange(ev) {
    this.severityName = "";
    this.severityName = ev?.label;
    console.log(this.severityName);
  }
  priorityChange(ev) {
    this.priorityName = "";
    this.priorityName = ev?.Name;
  }

  selectAllForDropdownItems(items: any[]) {
    let allSelect = (items) => {
      items.forEach((element) => {
        element["selectedAll"] = "Select All";
      });
    };
    allSelect(items);
  }

  selectSiteDropdown(items: any[]) {
    items.forEach((element) => {
      element["selectedAll"] = "Select All";
    });
    if (this.sitetype == 1) {
      this.selectedSite = items.map((item) => {
        return item.smSiteID;
      });
    }
  }

  searchSend() {
    let reqJson = {
      cnIDs: this.searchCountry.toString().replace(/[\[\]']+/g, '"'),
      ZoneIDs: this.SearchZone.toString().replace(/[\[\]']+/g, '"'),
      CircleIDs: this.searchRegionBindval.toString().replace(/[\[\]']+/g, '"'),
      ClusterIDs: this.searchCluster.toString().replace(/[\[\]']+/g, '"'),
      siteIDs: this.selectedSite.toString().replace(/[\[\]']+/g, '"'),
      customerIds: this.customerNameBindval
        .toString()
        .replace(/[\[\]']+/g, '"'),
      engineerIds: this.assignedEngiNameBindval,
      ttNumber: this.ttNumberBindval,
      ttStatusIds: this.selectedStatusBindval,
      startDate: this.startDateBindval,
      endDate: this.endDateBindval,
    };
    console.log("reqJson", reqJson);
  }

  openSearchModal(content, type) {
    this.disableTTNumDiv = false;
    this.disableclear = false;
    this.Modelservice.OpenModel(content, "lg");
    this.AddandEdit = "Add Ticket";
    if (type == "add") {
      this.clearTTLog();
    }
  }

  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    // this.autoSizeAll(true)
    // this.Exportdata.setSharedVariable(params);
  }

  onPageSizeChanged(e) {
    let _v = e.target.value;
    const value = _v;
    this.gridApi.paginationSetPageSize(Number(value));
  }
  onSelectionChanged(e) {
    let rowsSelection = this.gridApi.getSelectedRows();
    // this.Deleterow.checkedrows(rowsSelection);
  }

  gridHeaders: ColDef[] = [
    // {
    //   headerName: '',
    //   headerCheckboxSelection: true,
    //   checkboxSelection: true,
    //   width: 50,
    //   pinned: 'left',
    //   sortable: false,
    //   filter: false,
    // },
    {
      headerName: "TT ID",
      field: "ttID",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "TT Description",
      field: "ttDescription",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Status",
      field: "ttStatusName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Account",
      field: "acAccName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Application",
      field: "ttAppName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Customer",
      field: "cmCompanyName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Country",
      field: "cnName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Zone",
      field: "znZone",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Circle",
      field: "clCircle",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Cluster",
      field: "crName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Site ID",
      field: "smSiteCode",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Site Name",
      field: "smSiteName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Department",
      field: "departmentName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Raised By",
      field: "ttRaisedBy",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Assigned To",
      field: "ttAssignedTo",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Open Time",
      field: "ttOpenTime",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Close Time",
      field: "closedTime",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Closed By",
      field: "closedByName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Severity",
      field: "severityName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    {
      headerName: "Priority",
      field: "ttPriorityName",
      hide: false,
      cellRenderer: null,
      filter: "agTextColumnFilter",
      flex: 1,
      pinned: false,
      suppressColumnsToolPanel: false,
    },
    // {
    //   headerName: "Reporting Name",
    //   field: "Status",
    //   hide: false,
    //   cellRenderer: null,
    //   filter: "agTextColumnFilter",
    //   flex: 1,
    //   pinned: false,
    //   suppressColumnsToolPanel: false,
    // },
    // {
    //   headerName: "Reporting Time",
    //   field: "Open Time",
    //   hide: false,
    //   cellRenderer: null,
    //   filter: "agTextColumnFilter",
    //   flex: 1,
    //   pinned: false,
    //   suppressColumnsToolPanel: false,
    // },
    // {
    //   headerName: "Assign",
    //   headerTooltip: "Assign",
    //   cellRenderer: "assignAction",
    //   field: "siteConfigure",
    //   width: 100,
    //   suppressMovable: true,
    //   pinned: "right",
    //   suppressColumnsToolPanel: true,
    //   filter: null,
    //   cellRendererParams: {
    //     onAssignClick: this.onAssignClick.bind(this),
    //   },
    // },
    // {
    //   headerName: "Status Change",
    //   headerTooltip: "Status Change",
    //   cellRenderer: "statusChangeAction",
    //   field: "siteConfigure",
    //   width: 100,
    //   suppressMovable: true,
    //   pinned: "right",
    //   suppressColumnsToolPanel: true,
    //   filter: null,
    //   cellRendererParams: {
    //     onStatusChange: this.onStatusChange.bind(this),
    //   },
    // },
    // {
    //   headerName: "Close",
    //   headerTooltip: "Close",
    //   cellRenderer: "closeTicketAction",
    //   field: "Close",
    //   width: 100,
    //   suppressMovable: true,
    //   pinned: "right",
    //   suppressColumnsToolPanel: true,
    //   filter: null,
    //   cellRendererParams: {
    //     onCloseClick: this.onCloseClick.bind(this),
    //   },
    // },
    {
      headerName: "Edit",
      headerTooltip: "Edit",
      width: 100,
      pinned: "right",
      cellRenderer: "editCell",
      field: "edit",
      suppressColumnsToolPanel: true,
      filter: null,
      cellRendererParams: {
        onEditClick: this.onEdit.bind(this),
      },
    },
    {
      headerName: "Actions",
      headerTooltip: "Actions",
      tooltipField: "Actions",
      cellRenderer: "actionRenderer",
      width: 150,
      suppressMovable: true,
      pinned: "right",
      hide: false,
      filter: null,
      suppressColumnsToolPanel: true,
    },
  ];

  returnUndefined(id) {
    return id ? id : undefined;
  }

  onEdit(rowData: any): void {
    if (rowData) {
      this.modalService.dismissAll();
      this.clearTTLog();
      this.disableclear = true;
      this.disableTTNumDiv = true;
      this.AddandEdit = "Update Ticket";
      this.Modelservice.OpenModel(this.addAndUpdateTTLog, "lg");
      this.autoTTId = rowData.ttID;
      this.accountBindVal = this.returnUndefined(rowData.acAccID);
      this.accountName = rowData.acAccName;
      this.AddCountry = this.returnUndefined(rowData.cnID);
      this.countryName = rowData.cnName;
      this.AddZone = this.returnUndefined(rowData.znZoneID);
      this.zoneName = rowData.znZone;
      this.AddRegion = this.returnUndefined(rowData.clCircleID);
      this.regionName = rowData.clCircle;
      this.AddCluster = this.returnUndefined(rowData.crClusterID);
      this.clusterName = rowData.crName;
      this.appBindVal = this.returnUndefined(rowData.ttAppID);
      this.appName = rowData.ttAppName;
      this.customerBindVal = this.returnUndefined(rowData.cmCompanyID);
      this.customerName = rowData.cmCompanyName;
      this.siteBindVal = this.returnUndefined(rowData.smSiteID);
      this.siteCode = rowData.smSiteCode;
      this.siteName = rowData.smSiteName;
      this.departmentBindVal = this.returnUndefined(rowData.deptID);
      this.departmentName = rowData.departmentName;
      this.raisedByBindval = this.returnUndefined(rowData.ttRaisedByID);
      this.raisedByName = rowData.ttRaisedBy;
      this.AssignedBindVal = this.returnUndefined(rowData.ttAssignedToID);
      this.assignedToName = rowData.ttAssignedTo;
      // this.ttOpenTimeBindVal = rowData.ttOpenTime;
      console.log("rowData OpenTimeBindVal", rowData.ttOpenTime);
      //2024-11-28T20:00 03-03-2025 01:00:00
      if (rowData.ttOpenTime) {
        let openTime = rowData.ttOpenTime;
        let dateTime = openTime.split(" ");
        let splitDate = dateTime[0].split("-");
        let splitTime = dateTime[1].split(":");
        this.ttOpenTimeBindVal =
          splitDate[2] +
          "-" +
          splitDate[1] +
          "-" +
          splitDate[0] +
          "T" +
          dateTime[1];
      } else {
        this.ttOpenTimeBindVal = "";
      }
      console.log("this.ttOpenTimeBindVal", this.ttOpenTimeBindVal);
      this.assignStatusBindval = this.returnUndefined(rowData.ttStatusID);
      this.statusName = rowData.ttStatusName;
      this.SeverityBindval = this.returnUndefined(rowData.stID);
      this.severityName = rowData.severityName;
      this.priorityBindval = this.returnUndefined(rowData.ttPriorityID);
      this.priorityName = rowData.ttPriorityName;
      this.ReportingNameBindval = rowData.ttReporterName;
      this.ReportingTime = rowData.ttReportingTime;
      this.evtDescBindval = rowData.ttDescription;
      this.actionBindval = rowData.ttAction;
      this.addRemarksBindval = rowData.ttRemarks;
      this.getTTLogGridData();
    }
  }
  onStatusChange(rowData: any): void {
    if (rowData) {
      this.modalService.dismissAll();
      // this.disableclear = true;
      this.Modelservice.OpenModel(this.UpdateTTLogStatus, "lg");
      // this.getTTLogGridData();
    }
  }
  onAssignClick(rowData: any): void {
    if (rowData) {
      this.modalService.dismissAll();
      // this.disableclear = true;
      this.Modelservice.OpenModel(this.AssignTTLog, "lg");
      // this.getTTLogGridData();
    }
  }
  onCloseClick(rowData: any): void {
    if (rowData) {
      this.modalService.dismissAll();
      // this.disableclear = true;
      this.Modelservice.OpenModel(this.ttCloseTicket, "lg");
      // this.getTTLogGridData();
    }
  }
  TTLogStatusUpdate() {
    this.className = "loading";
    let json = {
      // siteID: this.smSiteId,
    };
    this.http
      .post(
        // this.urlAuthentication.newMastersUrl + this.apiUrl.saveSiteAlarmConfig,
        "https://jsonplaceholder.typicode.com/posts",
        json
      )
      .subscribe(
        (res: any) => {
          if (res) {
            this.className = "";
            Swal.fire(res.response.Data);
          }
        },
        (error) => {
          this.className = "";
          console.error(error);
        }
      );
  }

  AssignTTLogSubmit() {
    this.className = "loading";
    let json = {
      // siteID: this.smSiteId,
    };
    this.http
      .post(
        // this.urlAuthentication.newMastersUrl + this.apiUrl.saveSiteAlarmConfig,
        "https://jsonplaceholder.typicode.com/posts",
        json
      )
      .subscribe(
        (res: any) => {
          if (res) {
            this.className = "";
            Swal.fire(res.response.Data);
          }
        },
        (error) => {
          this.className = "";
          console.error(error);
        }
      );
  }
  getTTLogGridData() {
    // this.showGridLoader = true;
    let requestJson = {
      fmID: 3000,
    };
    this.http
      .genericApi(this.urlAuthentication.genericApiUrl, requestJson)
      .subscribe(
        (res: any) => {
          this.showGridLoader = false;
          this.ttLogGridData = [];
          this.ttLogGridData = res.response[0].Data;
          console.log("this.ttLogGridData : ", this.ttLogGridData);
          this.ttGridHeaders = [];
          this.ttGridHeaders = res.response[0].Header;
          console.log("this.ttGridHeaders : ", this.ttGridHeaders);
        },
        (error) => {
          this.showGridLoader = false;
          console.error(error);
        }
      );
  }

  formatDate(date: string | null | undefined, format: string): string | null {
    if (!date) {
      return "";
    }
    const [year, month, day] = date.split(" ")[0].split("-");
    const time = date.split(" ")[1];
    const dateString = `${year}-${month}-${day}`;
    const parsedDate = new Date(dateString);
    if (isNaN(parsedDate.getTime())) {
      console.error("Invalid date:", date);
      return "";
    }
    return this.datePipe.transform(parsedDate, format);
  }

  submitTTLogform() {
    this.className = "loading";
    let json = {
      ttID: this.autoTTId,
      acAccID: this.accountBindVal,
      acAccName: this.accountName,
      ttAppID: this.appBindVal,
      ttAppName: this.appName,
      cmCompanyID: this.customerBindVal,
      cmCompanyName: this.customerName,
      cnID: this.AddCountry,
      cnName: this.countryName,
      znZoneID: this.AddZone,
      znZone: this.zoneName,
      clCircleID: this.AddRegion,
      clCircle: this.regionName,
      crClusterID: this.AddCluster,
      crName: this.clusterName,
      smSiteID: this.siteBindVal,
      smSiteCode: this.siteCode,
      smSiteName: this.siteName,
      deptID: this.departmentBindVal,
      departmentName: this.departmentName,
      ttRaisedByID: this.raisedByBindval,
      ttRaisedBy: this.raisedByName,
      ttAssignedToID: this.AssignedBindVal,
      ttAssignedTo: this.assignedToName,
      ttOpenTime: this.formatDate(
        this.ttOpenTimeBindVal,
        "dd-MM-yyyy HH:mm:ss"
      ),
      ttStatusID: this.assignStatusBindval,
      ttStatusName: this.statusName,
      stID: this.SeverityBindval,
      severityName: this.severityName,
      ttPriorityID: this.priorityBindval,
      ttPriorityName: this.priorityName,
      ttReporterName: this.ReportingNameBindval,
      ttReportingTime: this.formatDate(
        this.ReportingTime,
        "dd-MM-yyyy HH:mm:ss"
      ),
      ttDescription: this.evtDescBindval,
      ttAction: this.actionBindval,
      ttRemarks: this.addRemarksBindval,
    };
    console.log("json", json);
    this.http
      .post(this.urlAuthentication.WfmTTLog + this.apiUrl.setTTLog, json)
      .subscribe(
        (res: any) => {
          console.log("response ", res);
          if (res) {
            this.className = "";
            Swal.fire({ text: res.response.Data });
            // { text: res.status, icon: "warning" }
            if (!res.response.Data.includes("already exists")) {
              this.className = "";
              this.modalService.dismissAll();
              this.getTTLogGridData();
            }
          }
        },
        (error) => {
          this.className = "";
          console.error(error);
          Swal.fire({ text: error.message });
        }
      );
  }

  resetSearch(searchForm) {
    searchForm.form.reset();
    // this.filterSearchList = [];
    // this.selectedRegion = [];
    // this.selectedZone = [];
    // this.selectedCluster = [];
    // this.selectedSiteType = [];
    // this.selectedSiteClass = [];
    // this.selectedEnergyClass = [];
    // this.selectedCoolingClass = [];
    // this.selectedTenantClass = [];
    // this.selectedVendor = [];
    // this.selectedSite = [];
    // this.selectedPowersource = [];
    // this.selectedOrder = [];
    // this.selectedCustID = "";
    // this.selectedDCVolts = undefined;
    // this.cannotAdd = "";
    // this.fieldsCounter = [];
    // this.additionalFieldLabel = "Need More ?";
    // this.searchFun();
  }

  clearTTLog() {
    this.accountBindVal = [];
    this.appBindVal = undefined;
    this.customerBindVal = undefined;
    this.AddCountry = "";
    this.AddZone = [];
    this.AddRegion = [];
    this.AddCluster = [];
    this.siteBindVal = [];
    this.departmentBindVal = undefined;
    this.raisedByNames = [];
    this.AssignedBindVal = undefined;
    this.assignStatusBindval = undefined;
    this.addRemarksBindval = "";
    this.searchCountry = [];
    this.SearchZone = [];
    this.searchRegionBindval = [];
    this.searchCluster = [];
    this.selectedSite = [];
    this.customerNameBindval = [];
    this.assignedEngiNameBindval = [];
    this.ttNumberBindval = "";
    this.selectedStatusBindval = [];
    this.startDateBindval = "";
    this.endDateBindval = "";
    this.actionBindval = "";
    // this.ttOpenTimeBindVal = "";
    this.evtDescBindval = "";
    this.ReportingNameBindval = "";
    this.priorityBindval = undefined;
    this.SeverityBindval = undefined;
    this.ReportingTime = "";
    this.raisedByBindval = undefined;
    this.autoTTId = 0;

    // other parameters
    this.ttCloseTime = "";
    this.TTNUmber = "";
    this.siteStatus = "";
    this.regionBindVal = "";
    this.contactBindval = "";
  }

  clearStatus() {
    this.statChgSelectedSite = "";
    this.newStatusBindval = "";
    this.statusBindval = [];
    this.statusRemark = "";
  }
  clearAssign() {
    this.AssignTTNumberBindval = "";
    this.assignSiteIdBindval = "";
    this.assignRemark = "";
    this.assignSiteNameBindval = "";
    this.engiIdBindVal = [];
    this.engiNameBindVal = [];
  }
}
