import { Component } from '@angular/core';
import { ICellRendererAngularComp } from '@ag-grid-community/angular';
import { Router } from '@angular/router';
import { ShareddataService } from '../../service/sharedDataService/shareddata.service';

@Component({
  selector: "app-status-cell-renderer",
  template: `
    <button
      type="button"
      class="btn btn-outline-warning"
      (click)="onClick($event)"
    >
      Status
    </button>
  `,
  styles: [],
})
export class TTLogStatusChangeComponent implements ICellRendererAngularComp {
  public params: any;
  smSiteId;
  siteCode;
  siteName;
  sendSiteInfoData;
  sendSiteName;
  constructor(
    private router: Router,
    private sharedDataService: ShareddataService
  ) {}

  ngOnInit() {}
  agInit(params: any): void {
    this.params = params;
    this.siteCode = this.params.data.smSiteCode;
    this.smSiteId = this.params.data.smSiteID;
    this.siteName = this.params.data.smSiteName;
  }
  onClick(event: any) {
    if (this.params && this.params.onStatusChange) {
      this.params.onStatusChange(this.params.data);
    }
  }

  refresh(): boolean {
    return false;
  }
}
