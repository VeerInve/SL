import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { FormsModule } from "@angular/forms";
import { NgxMaskModule } from "ngx-mask";
import { AgGridModule } from "ag-grid-angular";
import { NgSelectModule } from "@ng-select/ng-select";
import { TTLogRoutingModule } from "./ttlog-routing.module";
import { TTLogComponent } from "./ttlog.component";
import { TTLogAssignComponent } from "./Assign.component";
import { ActionRendererComponent } from "./ttlogActions.component";
import { SharedModule } from "../../Utils/shared/shared.module";

@NgModule({
  declarations: [TTLogComponent, TTLogAssignComponent, ActionRendererComponent],
  imports: [
    CommonModule,
    FormsModule,
    NgxMaskModule.forRoot(),
    AgGridModule,
    NgSelectModule,
    TTLogRoutingModule,
    SharedModule,
  ],
  exports: [TTLogComponent],
})
export class ttlogModule {}
