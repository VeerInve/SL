import { Component } from "@angular/core";
import { ICellRendererAngularComp } from "ag-grid-angular";

@Component({
  selector: "app-button-cell-renderer",
  template: `<button
    type="button"
    class="btn btn-primary"
    (click)="onClick($event)"
  >
    Edit
  </button>`,
})
export class editButtonCellRendererComponent
  implements ICellRendererAngularComp
{
  public params: any;

  agInit(params: any): void {
    this.params = params;
  }

  refresh(): boolean {
    return false;
  }

  onClick(event: any) {
    if (this.params && this.params.onEditClick) {
      this.params.onEditClick(this.params.data);
    }
    // if (this.params.onEditClick) {
    //   this.params.onEditClick(this.params.node.data);
    // } else {
    //   console.error('onEditClick function is not defined.');
    // }
  }
}
