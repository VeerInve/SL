# python imports
import datetime
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
import sys

# analysis tool imports
import pandas as pd
import numpy as np

# DB related imports
import pymysql
from sqlalchemy import create_engine
from sqlalchemy import MetaData, Column, Table
from sqlalchemy import String, Date, Float
import mysql.connector

# package imports
import setting as settings
import databaseRead

now = datetime.now()
systemTime = now.strftime("%Y-%m-%d %H:%M:%S")

# Read Database setting from setting file
try:
    conn = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                           user=settings.DATABASE_CONFIG['user'],
                           password=settings.DATABASE_CONFIG['password'],
                           db=settings.DATABASE_CONFIG['database'])

except pymysql.OperationalError:
    sys.exit()
except pymysql.InternalError:
    sys.exit()
# read setting parameters
host = settings.DATABASE_CONFIG['host']
user = settings.DATABASE_CONFIG['user']
password = settings.DATABASE_CONFIG['password']
db = settings.DATABASE_CONFIG['database']
port = settings.DATABASE_CONFIG['port']
schedulerFrequency = settings.PARAMTER_CONFIG['schedulerFrequency']

print(host)
print(user)
print(password)
print(db)
print(port)

try:

    engine = create_engine('mysql+pymysql://' + user + ':' + password + '@' + host + ':' + str(port) + '/' + db,
                           echo=False)
    metadata = MetaData(bind=engine)

except pymysql.OperationalError:
    sys.exit()
except pymysql.InternalError:
    sys.exit()


except mysql.connector.Error as error:
    print("parameterized query failed {}".format(error))

if __name__ == '__main__':

    pattern = '%Y-%m-%d %H:%M:%S'
    print('current systemTime = ', systemTime)
    clearTime_end = int(time.mktime(datetime.strptime(systemTime, pattern).timetuple()))
    print('clearTime_end', clearTime_end)
    # schedulerFrequency  = 300
    clearTime_start = clearTime_end - schedulerFrequency
    print('clearTime_start', clearTime_start)
    # Dummy Date
    day = now.day
    month = now.month
    year = now.year
    todayDate = date(year, month, day)
    print('todayDate', todayDate)
    schedulerdate = todayDate.strftime(("%Y-%m-%d"))
    print(schedulerdate)
    b_current_start = str(todayDate)
    t_start_current = " 00:00:00"
    start_current = b_current_start + t_start_current
    pattern = '%Y-%m-%d %H:%M:%S'
    start_day_current = str(datetime.strptime(start_current, pattern))
    print('todayDateTime', start_day_current)
    dummyDate_today_start = int(time.mktime(datetime.strptime(start_day_current, pattern).timetuple()))
    print('dummyDate_today', dummyDate_today_start)
    # schedulerdate = dummyDate_today_start
    # print('schedulerdate', dummyDate_today_start)
    t_end = " 23:59:59"
    end_today = b_current_start + t_end
    dummyDate_today_end = int(time.mktime(datetime.strptime(end_today, pattern).timetuple()))
    print('dummyDate_today_end', dummyDate_today_end)

    # Read Data for all parent outage alarms which is cleared before schduler running
    a_dayoutagewhenclearedDF = databaseRead.a_dayoutagewhencleared(conn, clearTime_start, clearTime_end)
    print(a_dayoutagewhenclearedDF.head())
    # Read Data for all parent outage when alarm is not cleared before schduler running
    a_dayoutagewhennotclearedDF = databaseRead.a_dayoutagewhennotcleared(conn)
    print(a_dayoutagewhennotclearedDF.head())

    combine_df_list = [a_dayoutagewhenclearedDF, a_dayoutagewhennotclearedDF]
    final_df_for_replace = pd.concat(combine_df_list)
    # final_df_for_replace.to_excel('D:/Application/a_dayoutagescheduler/data/temp_data/final_df_for_replace_1.xlsx')
    final_df_for_replace['socID'] = pd.to_numeric(final_df_for_replace['socID'], errors='coerce')
    final_df_for_replace['socID'].fillna(19,inplace = True)
    final_df_for_replace['socID'] = final_df_for_replace['socID'].astype(int)
    final_df_for_replace['sofeID'] = pd.to_numeric(final_df_for_replace['sofeID'], errors='coerce')
    final_df_for_replace['sofeID'].fillna(150, inplace=True)
    final_df_for_replace['sofeID'] = final_df_for_replace['sofeID'].astype(int)
    final_df_for_replace['ttLastUpdatedDt'] = pd.to_numeric(final_df_for_replace['ttLastUpdatedDt'], errors='coerce')
    final_df_for_replace['ttLastUpdatedDt'].fillna(-1, inplace=True)
    final_df_for_replace['ttLastUpdatedDt'] = final_df_for_replace['ttLastUpdatedDt'].astype(int)
    final_df_for_replace.replace(to_replace=["Normal BSC", "STRATEGIC BSC"],
                     value="BSC",inplace=True)

    for index, row in final_df_for_replace.iterrows():
        # print(index)
        # print(row)
        # print(row['ttid'], row['alName'], row['soStartDateTime'], row['soRestoreDateTime'])
        soRestoreDateTime = row['soRestoreDateTime']
        soStartDateTime = row['soStartDateTime']

        # When Parent Alarm is cleared before schduler is running
        if soRestoreDateTime > 0:
            # case 1:

            if dummyDate_today_start <= soRestoreDateTime <= dummyDate_today_end:
                print(row['ttid'], row['alName'], row['soStartDateTime'], row['soRestoreDateTime'])
                """
                           When openTime is between system current date range i.e between 00:00:00 and 23:59:59
                """
                if dummyDate_today_start <= soStartDateTime <= dummyDate_today_end:
                    print('*****************************  When openTime is between system current date range ')
                    # compute Outage Minutes
                    """
                    OutageMinutes = ClearTime - OpenTime
                    """
                    OutageinSeconds = soRestoreDateTime - soStartDateTime
                    OutageMinutes = OutageinSeconds / 60
                    OutageMinutes = round(OutageMinutes, 5)
                    # compute Uptime
                    """
                    Uptime% = 1440 - OutageMinutes/1440 * 100
                    """
                    totalTime = 1440
                    uptimeinMinutes = totalTime - OutageMinutes
                    uptimePercentage = uptimeinMinutes / totalTime * 100
                    uptimePercentage = round(uptimePercentage, 5)
                    ttid = row['ttid']
                    print(ttid)
                    SchedulerRunDate = schedulerdate
                    ttid = row['ttid']
                    znZoneID = row['znZoneID']
                    znZone = row['znZone']
                    clCircleID = row['clCircleID']
                    clCircle = row['clCircle']
                    crClusterID = row['crClusterID']
                    crName = row['crName']
                    smSiteID = row['smSiteID']
                    smPaceSiteCode = row['smPaceSiteCode']
                    smSiteName = row['smSiteName']
                    cmCompanyID = row['cmCompanyID']
                    ssmStatus = row['ssmStatus']
                    soStartDateTime1 = row['soStartDateTime']
                    soRestoreDateTime = row['soRestoreDateTime']
                    OutageMinutes = OutageMinutes
                    PercentageUptime = uptimePercentage
                    acAccID = row['acAccID']
                    cmCompanyVendorID = row['cmCompanyVendorID']
                    socID = row['socID']
                    sofeID = row['sofeID']
                    ttLastUpdatedDt = int(row['ttLastUpdatedDt'])
                    alID = row['alID']
                    alName = row['alName']
                    smtTypeID = row['smtTypeID']
                    smtTypeName = row['smtTypeName']
                    caID = 0
                    now = datetime.now()
                    systemTime = now.strftime("%Y-%m-%d %H:%M:%S")
                    pattern = '%Y-%m-%d %H:%M:%S'
                    dummydate = int(time.mktime(datetime.strptime(systemTime, pattern).timetuple()))
                    tupleRecord = (SchedulerRunDate,ttid,znZoneID,znZone,clCircleID,clCircle,crClusterID,crName,smSiteID,smPaceSiteCode,smSiteName,cmCompanyID,
                                ssmStatus,soStartDateTime1,soRestoreDateTime,OutageMinutes,PercentageUptime,acAccID,cmCompanyVendorID,socID,sofeID,ttLastUpdatedDt,
                                alID,alName,smtTypeID,smtTypeName,caID,dummydate)
                    # replace_request_1 = insertData.replaceData(connection,tupleRecord)
                    try:
                        conn1 = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                                                user=settings.DATABASE_CONFIG['user'],
                                                password=settings.DATABASE_CONFIG['password'],
                                                db=settings.DATABASE_CONFIG['database'])
                        cursor = conn1.cursor()

                        # Preparing the query to update the records
                        sql_replace_query = "REPLACE INTO  `a_dayoutage` (`SchedulerRunDate`,`ttid`,`znZoneID`,`znZone`,`clCircleID`,`clCircle`,`crClusterID`,`crName`,`smSiteID`,`smPaceSiteCode`,`smSiteName`,`cmCompanyID`,`ssmStatus`,`soStartDateTime`,`soRestoreDateTime`,`OutageMinutes`,`PercentageUptime`,`acAccID`,`cmCompanyVendorID`,`socID`,`sofeID`,`ttLastUpdatedDt`,`alID`,`alName`,`smtTypeID`,`smtTypeName`,`caID`,`dummydate`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"

                        # Execute the SQL command
                        print(tupleRecord)
                        print("Data before execution successfully into  table using the prepared statement")
                        cursor.execute(sql_replace_query, tupleRecord)
                        print("Data executed successfully into table using the prepared statement")

                        # Commit your changes in the database
                        conn1.commit()
                        print("Data inserted successfully into table using the prepared statement")
                    except mysql.connector.Error as error:
                        # Rollback in case there is any error
                        conn1.rollback()
                    finally:
                        cursor.close()
                        conn1.close()
                        print("MySQL connection is closed")
                        print('inline1')

                else:
                    """
                                   When openTime < system current date range 
                    """
                    print('*****************************  When openTime < system current date range ')
                    # compute Outage Minutes
                    """
                    OutageMinutes = ClearTime -  dummyDate_today_start(Current Date + time(00:00:00)
                    """
                    OutageinSeconds = soRestoreDateTime - dummyDate_today_start
                    OutageMinutes = OutageinSeconds / 60
                    OutageMinutes = round(OutageMinutes, 5)
                    # compute Uptime
                    """
                    Uptime% = 1440 - OutageMinutes/1440 * 100
                    """
                    totalTime = 1440
                    uptimeinMinutes = totalTime - OutageMinutes
                    uptimePercentage = uptimeinMinutes / totalTime * 100
                    uptimePercentage = round(uptimePercentage, 5)
                    ttid = row['ttid']
                    print(ttid)
                    SchedulerRunDate = schedulerdate
                    ttid = row['ttid']
                    znZoneID = row['znZoneID']
                    znZone = row['znZone']
                    clCircleID = row['clCircleID']
                    clCircle = row['clCircle']
                    crClusterID = row['crClusterID']
                    crName = row['crName']
                    smSiteID = row['smSiteID']
                    smPaceSiteCode = row['smPaceSiteCode']
                    smSiteName = row['smSiteName']
                    cmCompanyID = row['cmCompanyID']
                    ssmStatus = row['ssmStatus']
                    soStartDateTime2 = dummyDate_today_start
                    soRestoreDateTime = row['soRestoreDateTime']
                    OutageMinutes = OutageMinutes
                    PercentageUptime = uptimePercentage
                    acAccID = row['acAccID']
                    cmCompanyVendorID = row['cmCompanyVendorID']
                    socID = row['socID']
                    sofeID = row['sofeID']
                    ttLastUpdatedDt = int(row['ttLastUpdatedDt'])
                    alID = row['alID']
                    alName = row['alName']
                    smtTypeID = row['smtTypeID']
                    smtTypeName = row['smtTypeName']
                    caID = 0
                    now = datetime.now()
                    systemTime = now.strftime("%Y-%m-%d %H:%M:%S")
                    pattern = '%Y-%m-%d %H:%M:%S'
                    dummydate = int(time.mktime(datetime.strptime(systemTime, pattern).timetuple()))
                    tupleRecord = (
                    SchedulerRunDate, ttid, znZoneID, znZone, clCircleID, clCircle, crClusterID, crName, smSiteID,
                    smPaceSiteCode, smSiteName, cmCompanyID,
                    ssmStatus, soStartDateTime2, soRestoreDateTime, OutageMinutes, PercentageUptime, acAccID,
                    cmCompanyVendorID, socID, sofeID, ttLastUpdatedDt,
                    alID, alName, smtTypeID, smtTypeName, caID,dummydate)
                    # replace_request_1 = insertData.replaceData(connection,tupleRecord)
                    try:
                        conn2 = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                                               user=settings.DATABASE_CONFIG['user'],
                                               password=settings.DATABASE_CONFIG['password'],
                                               db=settings.DATABASE_CONFIG['database'])
                        cursor = conn2.cursor()

                        # Preparing the query to update the records
                        sql_replace_query = "REPLACE INTO  `a_dayoutage` (`SchedulerRunDate`,`ttid`,`znZoneID`,`znZone`,`clCircleID`,`clCircle`,`crClusterID`,`crName`,`smSiteID`,`smPaceSiteCode`,`smSiteName`,`cmCompanyID`,`ssmStatus`,`soStartDateTime`,`soRestoreDateTime`,`OutageMinutes`,`PercentageUptime`,`acAccID`,`cmCompanyVendorID`,`socID`,`sofeID`,`ttLastUpdatedDt`,`alID`,`alName`,`smtTypeID`,`smtTypeName`,`caID`,`dummydate`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"

                        # Execute the SQL command
                        print(tupleRecord)
                        print("Data before execution successfully into employee table using the prepared statement")
                        cursor.execute(sql_replace_query,tupleRecord)
                        print("Data executed successfully into  table using the prepared statement")

                        # Commit your changes in the database
                        conn2.commit()
                        print("Data inserted successfully into  table using the prepared statement")



                    except mysql.connector.Error as error:
                        # Rollback in case there is any error
                        conn2.rollback()
                    finally:

                        cursor.close()
                        conn2.close()
                        print("MySQL connection is closed")
                        print('inline2')

            else:
               pass

        else:
            """
            When Alarm is not cleared for current day
            """
            # Case 1 : When openTime is between system current date range i.e between 00:00:00 and 23:59:59
            if dummyDate_today_start <= soStartDateTime <= dummyDate_today_end:
                print(soStartDateTime)
                now = datetime.now()
                systemTime = now.strftime("%Y-%m-%d %H:%M:%S")
                pattern = '%Y-%m-%d %H:%M:%S'
                clearTime_end1 = int(time.mktime(datetime.strptime(systemTime, pattern).timetuple()))
                # compute Outage Minutes
                """
                OutageMinutes = ClearTime - OpenTime
                """
                OutageinSeconds = clearTime_end1 - soStartDateTime
                OutageMinutes = OutageinSeconds / 60
                OutageMinutes = round(OutageMinutes, 5)
                # compute Uptime
                """
                Uptime% = 1440 - OutageMinutes/1440 * 100
                """
                totalTime = 1440
                uptimeinMinutes = totalTime - OutageMinutes
                uptimePercentage = uptimeinMinutes / totalTime * 100
                uptimePercentage = round(uptimePercentage, 5)
                ttid = row['ttid']
                print(ttid)
                SchedulerRunDate = schedulerdate
                ttid = row['ttid']
                znZoneID = row['znZoneID']
                znZone = row['znZone']
                clCircleID = row['clCircleID']
                clCircle = row['clCircle']
                crClusterID = row['crClusterID']
                crName = row['crName']
                smSiteID = row['smSiteID']
                smPaceSiteCode = row['smPaceSiteCode']
                smSiteName = row['smSiteName']
                cmCompanyID = row['cmCompanyID']
                ssmStatus = row['ssmStatus']
                soStartDateTime3 = row['soStartDateTime']
                soRestoreDateTime = row['soRestoreDateTime']
                OutageMinutes = OutageMinutes
                PercentageUptime = uptimePercentage
                acAccID = row['acAccID']
                cmCompanyVendorID = row['cmCompanyVendorID']
                socID = row['socID']
                sofeID = row['sofeID']
                ttLastUpdatedDt = int(row['ttLastUpdatedDt'])
                alID = row['alID']
                alName = row['alName']
                smtTypeID = row['smtTypeID']
                smtTypeName = row['smtTypeName']
                caID = 0
                now = datetime.now()
                systemTime = now.strftime("%Y-%m-%d %H:%M:%S")
                pattern = '%Y-%m-%d %H:%M:%S'
                dummydate = int(time.mktime(datetime.strptime(systemTime, pattern).timetuple()))

                tupleRecord = (
                SchedulerRunDate, ttid, znZoneID, znZone, clCircleID, clCircle, crClusterID, crName, smSiteID,
                smPaceSiteCode, smSiteName, cmCompanyID,
                ssmStatus, soStartDateTime3, soRestoreDateTime, OutageMinutes, PercentageUptime, acAccID,
                cmCompanyVendorID, socID, sofeID, ttLastUpdatedDt,
                alID, alName, smtTypeID, smtTypeName, caID,dummydate)
                # replace_request_1 = insertData.replaceData(connection,tupleRecord)
                try:
                    conn3 = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                                            user=settings.DATABASE_CONFIG['user'],
                                            password=settings.DATABASE_CONFIG['password'],
                                            db=settings.DATABASE_CONFIG['database'])
                    cursor = conn3.cursor()

                    # Preparing the query to update the records
                    sql_replace_query = "REPLACE INTO  `a_dayoutage` (`SchedulerRunDate`,`ttid`,`znZoneID`,`znZone`,`clCircleID`,`clCircle`,`crClusterID`,`crName`,`smSiteID`,`smPaceSiteCode`,`smSiteName`,`cmCompanyID`,`ssmStatus`,`soStartDateTime`,`soRestoreDateTime`,`OutageMinutes`,`PercentageUptime`,`acAccID`,`cmCompanyVendorID`,`socID`,`sofeID`,`ttLastUpdatedDt`,`alID`,`alName`,`smtTypeID`,`smtTypeName`,`caID`,`dummydate`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"

                    # # tuple to insert at placeholder
                    # tuple = (SchedulerRunDate,ttid,znZoneID,znZone,clCircleID,clCircle,crClusterID,crName,smSiteID,smPaceSiteCode,smSiteName,cmCompanyID,
                    #                         ssmStatus,soStartDateTime,soRestoreDateTime,OutageMinutes,PercentageUptime,acAccID,cmCompanyVendorID,socID,sofeID,ttLastUpdatedDt,
                    #                         alID,alName,smtTypeID,smtTypeName,caID)

                    # Execute the SQL command
                    print(tupleRecord)
                    print("Data before execution successfully into  table using the prepared statement")
                    cursor.execute(sql_replace_query, tupleRecord)
                    print("Data executed successfully into  table using the prepared statement")

                    # Commit your changes in the database
                    conn3.commit()
                    print("Data inserted successfully into  table using the prepared statement")



                except mysql.connector.Error as error:
                    # Rollback in case there is any error
                    conn3.rollback()
                finally:

                    cursor.close()
                    conn3.close()
                    print("MySQL connection is closed")

                    print('inline3')
            else:
                """
                    When openTime < system current date range 
                """
                print('***************************** Case:4 When openTime < system current date range ')
                # compute Outage Minutes
                """
                OutageMinutes = ClearTime -  dummyDate_today_start(Current Date + time(00:00:00)
                """
                now = datetime.now()
                systemTime = now.strftime("%Y-%m-%d %H:%M:%S")
                pattern = '%Y-%m-%d %H:%M:%S'
                clearTime_end = int(time.mktime(datetime.strptime(systemTime, pattern).timetuple()))
                dummydate = clearTime_end
                OutageinSeconds = clearTime_end - dummyDate_today_start
                OutageMinutes = OutageinSeconds / 60
                OutageMinutes = round(OutageMinutes, 5)
                # compute Uptime
                """
                Uptime% = 1440 - OutageMinutes/1440 * 100
                """
                totalTime = 1440
                uptimeinMinutes = totalTime - OutageMinutes
                uptimePercentage = uptimeinMinutes / totalTime * 100
                uptimePercentage = round(uptimePercentage, 5)
                ttid = row['ttid']
                print(ttid)
                SchedulerRunDate = schedulerdate
                ttid = row['ttid']
                znZoneID = row['znZoneID']
                znZone = row['znZone']
                clCircleID = row['clCircleID']
                clCircle = row['clCircle']
                crClusterID = row['crClusterID']
                crName = row['crName']
                smSiteID = row['smSiteID']
                smPaceSiteCode = row['smPaceSiteCode']
                smSiteName = row['smSiteName']
                cmCompanyID = row['cmCompanyID']
                ssmStatus = row['ssmStatus']
                soStartDateTime4 = dummyDate_today_start
                soRestoreDateTime = row['soRestoreDateTime']
                OutageMinutes = OutageMinutes
                PercentageUptime = uptimePercentage
                acAccID = row['acAccID']
                cmCompanyVendorID = row['cmCompanyVendorID']
                socID = int(row['socID'])
                sofeID = row['sofeID']
                ttLastUpdatedDt = int(row['ttLastUpdatedDt'])
                alID = row['alID']
                alName = row['alName']
                smtTypeID = row['smtTypeID']
                smtTypeName = row['smtTypeName']
                caID = 0
                tupleRecord = (
                    SchedulerRunDate, ttid, znZoneID, znZone, clCircleID, clCircle, crClusterID, crName, smSiteID,
                    smPaceSiteCode, smSiteName, cmCompanyID,
                    ssmStatus, soStartDateTime4, soRestoreDateTime, OutageMinutes, PercentageUptime, acAccID,
                    cmCompanyVendorID, socID, sofeID, ttLastUpdatedDt,
                    alID, alName, smtTypeID, smtTypeName, caID,dummydate)
                # replace_request_1 = insertData.replaceData(connection,tupleRecord)
                try:
                    conn4 = pymysql.connect(host=settings.DATABASE_CONFIG['host'],
                                            user=settings.DATABASE_CONFIG['user'],
                                            password=settings.DATABASE_CONFIG['password'],
                                            db=settings.DATABASE_CONFIG['database'])
                    cursor = conn4.cursor()

                    # Preparing the query to update the records
                    sql_replace_query = "REPLACE INTO  `a_dayoutage` (`SchedulerRunDate`,`ttid`,`znZoneID`,`znZone`,`clCircleID`,`clCircle`,`crClusterID`,`crName`,`smSiteID`,`smPaceSiteCode`,`smSiteName`,`cmCompanyID`,`ssmStatus`,`soStartDateTime`,`soRestoreDateTime`,`OutageMinutes`,`PercentageUptime`,`acAccID`,`cmCompanyVendorID`,`socID`,`sofeID`,`ttLastUpdatedDt`,`alID`,`alName`,`smtTypeID`,`smtTypeName`,`caID`,`dummydate`) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)"

                    # # tuple to insert at placeholder
                    # tuple = (SchedulerRunDate,ttid,znZoneID,znZone,clCircleID,clCircle,crClusterID,crName,smSiteID,smPaceSiteCode,smSiteName,cmCompanyID,
                    #                         ssmStatus,soStartDateTime,soRestoreDateTime,OutageMinutes,PercentageUptime,acAccID,cmCompanyVendorID,socID,sofeID,ttLastUpdatedDt,
                    #                         alID,alName,smtTypeID,smtTypeName,caID)

                    # Execute the SQL command
                    print(tupleRecord)
                    print("Data before execution successfully into  table using the prepared statement")
                    cursor.execute(sql_replace_query, tupleRecord)
                    print("Data executed successfully into employee table using the prepared statement")

                    # Commit your changes in the database
                    conn4.commit()
                    print("Data inserted successfully into  table using the prepared statement")



                except mysql.connector.Error as error:
                    # Rollback in case there is any error
                    conn4.rollback()
                finally:

                    cursor.close()
                    conn4.close()
                    print("MySQL connection is closed")
                    print('inline4')
            # logics for not cleared outage


