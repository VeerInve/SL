import pandas as pd
import mysql.connector
import setting as settings

# read setting parameters
host = settings.DATABASE_CONFIG['host']
user = settings.DATABASE_CONFIG['user']
password = settings.DATABASE_CONFIG['password']
db = settings.DATABASE_CONFIG['database']
port = settings.DATABASE_CONFIG['port']
print('******')
print(host)
print(user)
print(password)
print(db)
print(port)
# except mysql.connector.Error as error:
#     print("parameterized query failed {}".format(error))


def replaceData(connection,tupleRecord):
    print(tupleRecord)
    tupleRecordd= tupleRecord
    try:
        # connection = mysql.connector.connect(host=host,
        #                                      database=db,
        #                                      user=user,
        #                                      password=password,
        #                                      port=port)
        # # establishing the connection

        # Creating a cursor object using the cursor() method
        cursor = connection.cursor()


        # Preparing the query to update the records
        sql_replace_query  = ("INSERT INTO  a_dayoutage_1 "
                                "(SchedulerRunDate,ttid,znZoneID,znZone,clCircleID,clCircle,crClusterID,crName,smSiteID,smPaceSiteCode,smSiteName,cmCompanyID,ssmStatus,soStartDateTime,soRestoreDateTime,OutageMinutes,PercentageUptime,acAccID,cmCompanyVendorID,socID,sofeID,ttLastUpdatedDt,alID,alName,smtTypeID,smtTypeName,caID) "
                                "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)")

        # # tuple to insert at placeholder
        # tuple = (SchedulerRunDate,ttid,znZoneID,znZone,clCircleID,clCircle,crClusterID,crName,smSiteID,smPaceSiteCode,smSiteName,cmCompanyID,
        #                         ssmStatus,soStartDateTime,soRestoreDateTime,OutageMinutes,PercentageUptime,acAccID,cmCompanyVendorID,socID,sofeID,ttLastUpdatedDt,
        #                         alID,alName,smtTypeID,smtTypeName,caID)

        # Execute the SQL command
        print("Data before execution successfully into employee table using the prepared statement")
        cursor.execute(sql_replace_query, tupleRecordd)
        print("Data executed successfully into employee table using the prepared statement")

        # Commit your changes in the database
        connection.commit()
        print("Data inserted successfully into employee table using the prepared statement")
    except mysql.connector.Error as error:
        # Rollback in case there is any error
        connection.rollback()
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed")

    # # Retrieving data
    # sql = '''SELECT * from a_dayoutage_1'''
    #
    # # Executing the query
    # cursor.execute(sql)
    #
    # # Displaying the result
    # # print(cursor.fetchall())
    # columns = [column[0] for column in cursor.description]
    # resultSet = cursor.fetchall()
    # results = []
    #
    # for row in resultSet:
    #     results.append(dict(zip(columns, row)))
    #
    # nums = [x for x in range(len(results))]
    #
    # a_dayoutagewhencleareddict = dict(zip(nums, results))
    # a_dayoutagewhencleareddf = pd.DataFrame.from_dict(a_dayoutagewhencleareddict, orient='index')
    #
    # return a_dayoutagewhencleareddf

    # Closing the connection
    # connection.close()