import pandas as pd


def a_dayoutagewhencleared(conn,start, end):

    start_time = start
    end_time = end
    dictCursor = conn.cursor()
    dictCursor.execute(
        """ SELECT 
                    t.ttID AS ttid,
                    m_circle.znZoneID AS znZoneID,
                    m_zone.znZone AS znZone,
                    m_circle.clCircleID AS clCircleID,
                    m_circle.clCircle AS clCircle,
                    m_site.crClusterID AS crClusterID,
                    m_cluster.crName AS crName,
                    m_site.smSiteID AS smSiteID,
                    m_site.smPaceSiteCode AS smPaceSiteCode,
                    m_site.smSiteName AS smSiteName,
                    t.cmCompanyID AS cmCompanyID,
                    m_sitestatusmaster.ssmStatus AS ssmStatus,
                    t.ttOpenTime AS soStartDateTime,
                    t.ttClearTime AS soRestoreDateTime,
                    t.acAccID AS acAccID,
                    m_site.cmCompanyVendorID AS cmCompanyVendorID,
                    t.socID AS socID,
                    t.sofeID AS sofeID,
                    t.ttLastUpdatedDt as ttLastUpdatedDt,
                    t.alID AS alID,
                    m_alarmnames.alName AS alName,
                    m_sitetype.smtTypeID,
                    m_sitetype.smtTypeName,
                    t_visitlog.caID AS caID,
                    m_powerdetails.pdCategory AS pdCategory,
                    m_powerdetails.pdName AS pdName

                    FROM t_troubleticketlog AS t
                      JOIN m_site 
                            ON (t.smSiteID = m_site.smSiteID)
                         JOIN m_alarmnames 
                            ON (t.alID = m_alarmnames.alID)
                         JOIN m_circle 
                            ON (t.clCircleID = m_circle.clCircleID)
                         JOIN m_cluster 
                            ON (m_site.crClusterID = m_cluster.crClusterID)
                         JOIN m_sitestatusmaster 
                            ON (m_site.ssmID = m_sitestatusmaster.ssmID)
                         JOIN m_powerdetails 
                            ON (m_site.pdId = m_powerdetails.pdID) 
                         JOIN m_zone 
                            ON (m_circle.znZoneID = m_zone.znZoneID) 
                         JOIN m_sitetype
                        ON (m_site.smSiteType = m_sitetype.smtTypeID)
                         LEFT JOIN t_visitlog 
                            ON (t.ttID = t_visitlog.ttID)
                   WHERE t.ttisParent=0 AND t.ttClearTime !=0 AND t.isOutageTT =1 AND t.ttLastUpdatedDt >= %s AND t.ttLastUpdatedDt <= %s """,
            (start_time, end_time))

    columns = [column[0] for column in dictCursor.description]

    resultSet = dictCursor.fetchall()
    results = []

    for row in resultSet:
        results.append(dict(zip(columns, row)))

    nums = [x for x in range(len(results))]

    a_dayoutagewhencleareddict = dict(zip(nums, results))
    a_dayoutagewhencleareddf = pd.DataFrame.from_dict(a_dayoutagewhencleareddict, orient='index')

    return a_dayoutagewhencleareddf

def a_dayoutagewhennotcleared(conn):

    dictCursor = conn.cursor()
    dictCursor.execute(
        """ SELECT 
                    t.ttID AS ttid,
                    m_circle.znZoneID AS znZoneID,
                    m_zone.znZone AS znZone,
                    m_circle.clCircleID AS clCircleID,
                    m_circle.clCircle AS clCircle,
                    m_site.crClusterID AS crClusterID,
                    m_cluster.crName AS crName,
                    m_site.smSiteID AS smSiteID,
                    m_site.smPaceSiteCode AS smPaceSiteCode,
                    m_site.smSiteName AS smSiteName,
                    t.cmCompanyID AS cmCompanyID,
                    m_sitestatusmaster.ssmStatus AS ssmStatus,
                    t.ttOpenTime AS soStartDateTime,
                    t.ttClearTime AS soRestoreDateTime,
                    t.acAccID AS acAccID,
                    m_site.pdId AS cmCompanyVendorID,
                    t.socID AS socID,
                    t.sofeID AS sofeID,
                    t.ttLastUpdatedDt as ttLastUpdatedDt,
                    t.alID AS alID,
                    m_alarmnames.alName AS alName,
                    m_sitetype.smtTypeID,
                    m_sitetype.smtTypeName,
                    t_visitlog.caID AS caID,
                    m_powerdetails.pdCategory AS pdCategory,
                    m_powerdetails.pdName AS pdName

                    FROM t_troubleticketlog AS t
                      JOIN m_site 
                            ON (t.smSiteID = m_site.smSiteID)
                         JOIN m_alarmnames 
                            ON (t.alID = m_alarmnames.alID)
                         JOIN m_circle 
                            ON (t.clCircleID = m_circle.clCircleID)
                         JOIN m_cluster 
                            ON (m_site.crClusterID = m_cluster.crClusterID)
                         JOIN m_sitestatusmaster 
                            ON (m_site.ssmID = m_sitestatusmaster.ssmID)
                         JOIN m_powerdetails 
                            ON (m_site.pdId = m_powerdetails.pdID) 
                         JOIN m_zone 
                            ON (m_circle.znZoneID = m_zone.znZoneID) 
                         JOIN m_sitetype
                        ON (m_site.smSiteType = m_sitetype.smtTypeID)
                         LEFT JOIN t_visitlog 
                            ON (t.ttID = t_visitlog.ttID)
                   WHERE t.isOutageTT =1  AND t.ttisParent=0 AND t.ttClearTime =0""")

    columns = [column[0] for column in dictCursor.description]

    resultSet = dictCursor.fetchall()
    results = []

    for row in resultSet:
        results.append(dict(zip(columns, row)))

    nums = [x for x in range(len(results))]

    a_dayoutagewhencleareddf = dict(zip(nums, results))
    a_dayoutagewhencleared_df = pd.DataFrame.from_dict(a_dayoutagewhencleareddf, orient='index')

    return a_dayoutagewhencleared_df

